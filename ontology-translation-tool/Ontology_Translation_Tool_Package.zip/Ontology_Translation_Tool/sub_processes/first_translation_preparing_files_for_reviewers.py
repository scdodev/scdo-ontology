#program_name: first_translation_preparing_files_for_reviewers.py

#13 May 2021
#Jade Hotchkiss

from tkinter import *
import tkinter as tk
from tkinter import messagebox

from openpyxl import Workbook
from openpyxl import load_workbook

import time
import os
from datetime import datetime   

### creates the main program class
class run_program:    
    def __init__(self, window):
        
        #### Adds the main instruction/label to the window
        label1 = tk.Label(text="Please enter the required info below:",
                          fg="white",
                          bg="black",
                          width=100,
                          height=3)
        label1.place(x=0, y=0)
        label1.pack()

        ### Adds a space after the second menu
        frame = tk.Frame(window, height=20)
        frame.pack()
        
        ### Creates entry field for ontology input file path
        entry_label1 = tk.Label(text="File path of input file:\n(template used: input_template_first_translation_prep)")
        entry_label1.pack()
        self.entry1 = tk.Entry(width=98)
        self.entry1.pack()        

        #### Creates entry field for ontology input file path
        #entry_label1 = tk.Label(text="File path of OWL ontology file to be translated:")
        #entry_label1.pack()
        #self.entry1 = tk.Entry(width=90)
        #self.entry1.pack()

        #### Adds a space after the second menu
        #frame = tk.Frame(window, height=20)
        #frame.pack()
        
        #### Creates entry field for primary language tag
        #entry_label2 = tk.Label(text="Language tag of ontology primary language (e.g. 'en' for English):")
        #entry_label2.pack()
        #self.entry2 = tk.Entry(width=40)
        #self.entry2.pack()    
        
        #### Adds a space after the second menu
        #frame = tk.Frame(window, height=10)
        #frame.pack()        

        #### Creates checkbox for whether the input ontology file already has language tags or not
        #self.CheckVar1 = IntVar()
        #checkbox1 = tk.Checkbutton(text="Does the ontology input file already contain primary language tags? (tick if yes)",
                                         #variable = self.CheckVar1,
                                         #onvalue = 1, offvalue = 0,
                                         #height = 3)
        #checkbox1.pack()


        #### Creates checkbox for whether annotations other than label and definition need to be translated
        #self.CheckVar2 = IntVar()
        #checkbox2 = tk.Checkbutton(text="Are ONLY labels and definitions to be translated for terms? (tick if yes) [Note: properties always only have their labels and definitions translated]",
                                         #variable = self.CheckVar2,
                                         #onvalue = 1, offvalue = 0,
                                         #height = 3)
        #checkbox2.pack()
        
        ### Adds a space after the second menu
        frame = tk.Frame(window, height=10)
        frame.pack()
        
        ### Creates a run button and tells it to run the run_code() function when clicked
        run_button = tk.Button(text = "Run", justify = RIGHT, command = self.run_code, fg="black", bg="SlateGray3")
        run_button.pack()
        
        ### Adds a space after the second menu
        frame = tk.Frame(window, height=10)
        frame.pack()
        
        ##### Adds the main instruction/label to the window
        #label1 = tk.Label(text="Note:\nIn addition to the information provided in the above file,\n ensure that the IDs and labels  of your ontology's label and defintion annotation properties\n are correct in the label_and_def_prop_ids.txt file.\nEdit the content of this file if necessary.",
                          #fg="black",
                          #bg="orange",
                          #width=100,
                          #height=5)
        #label1.place(x=0, y=0)
        #label1.pack()        

    ### Defines the run_code() function, which, depending on the input, will run various python programs and generate various output files
    def run_code(self): 
        input_file_path = self.entry1.get()
        
        if input_file_path == "":
            messagebox.showerror(title="Error", message="Before you can continue, please complete the entry field.")
                   
        else:
            ### Opens input file to obtain necessary paths of other input files
            workbook = load_workbook(input_file_path)
            sheet = workbook.active   
                
            owl_file_path = sheet['B1'].value
            anns_to_translate_file_path = sheet['B3'].value
            has_lang_tags = sheet['B5'].value
            primary_lang_tag = sheet['B7'].value
        
            current_working_directory = os.getcwd() #gets the current working directory path to use in the path for the new file below
        
            if owl_file_path == None or anns_to_translate_file_path == None or has_lang_tags == None or primary_lang_tag == None:
                print("One or more items in the input file were not provided or were provided incorrectly. Please ensure the input file is completed correctly and rerun this command.")
                 
            else:
                os.chdir(current_working_directory +'\\sub_processes')
                current_working_directory = os.getcwd() #gets the current working directory path to use in the path for the new file below
                
                ### Writes a txt file with the path of the input file
                newf = open(current_working_directory + "\\first_time_prep_input" + '.txt','w', encoding="utf8") # creates the output file using the name constructed above
                newf.write(input_file_path)
                newf.close()
                
                if has_lang_tags == "no" or has_lang_tags == "yes": #only continues loop if statement if content given is in correct format
                    if has_lang_tags == "no": # only done if the ontology does not already contain language tags on the relevant annotations
                    
                        os.system('python adding_lang_tags_1_GUI.py') # runs the program that adds primary language tags to the labels and definitions of the untranlated ontology file
                else:
                    print("The third item in the input file is not as expected. Please ensure the input is provided correctly and rerun this command.")
                    
                os.system('python extracting_terms_for_review_3_GUI.py') # runs the program that extracts term annotations for translation
                
                #os.system('python extracting_ontology_metadata_from_ontology_GUI.py') # runs the program that extracts property annotations for translation
                
                os.system('python extracting_property_annotations_from_ontology_GUI.py') # runs the program that extracts property annotations for translation
        
        print(">>>>>>")
        print("The program ran successfully. The generated files should be in the relevant folder in the 'output' folder.")
        
        window.destroy()
                                
window = tk.Tk() # creates the window
window.title("First Time Translating Ontology - Preparing Files for Reviewers") # sets the window's title

###runs Tkinter event loop (listens for button clicks or keypresses, and blocks code coming after from running until the window is closed)
run_program(window)
window.mainloop() 