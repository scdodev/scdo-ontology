#extracting_terms_for_review_3_GUI.py

#Programme that writes ID, labels and definitions, and any other terms specified in an input file, of all non-deprecated terms/classes from an ontology to an Excel file, using an Excel template file.
     
#24 June 2021
#Jade Hotchkiss

from owlready2 import *

import os
from datetime import datetime

import shutil
from openpyxl import Workbook
from openpyxl import load_workbook

### Copies the template workbook for terms to be reveiwed to the "output" folder and renames it as ""
def copy_terms_for_review_template(excel_template_file, outputfile_name):
     shutil.copy(excel_template_file, outputfile_name)

##### Extracts labels and descriptions of terms and writes them to an output file #####
def write_term_annotations_to_excel(owl_file_path, anns_to_translate_file_path, outputfile_name):
     onto = get_ontology(owl_file_path).load()  # loads the ontology as an "onto" object
     
     ann_to_translate_workbook = load_workbook(anns_to_translate_file_path)
     anns_sheet = ann_to_translate_workbook.active    
          
     term_ann_properties_list = [] # list of annotation properties (in a "term.XXX" format, where XXX is the property ID) that that should be translated    
     
     extra_headers = []
     
     ### Iterates through rows in sheet, skipping first row and column, and adds content to above lists
     for row in anns_sheet.iter_rows(min_row=2, min_col=2, max_col=3):
          annotation_ID = row[0].value
          annotation_label = row[1].value
          if annotation_ID !=  None and annotation_ID != "Annotation property ID": # ensures that empty rows and the header row are skipped
               if annotation_ID not in term_ann_properties_list: # if the annotation property ID is not already in the "term_ann_properties_list" list...
                    term_ann_properties_list.append("term." + str(annotation_ID)) # adds a string starting with "term." followed by the annotations's ID to the "term_ann_properties_list" list          
                    extra_headers.append("current " + str(annotation_label))
                    extra_headers.append("current " + str(annotation_label) + " translation")
                    extra_headers.append("reviewed " + str(annotation_label) + " translation")
                    extra_headers.append("validation provided for translation")
     
     ### Loads the copied output file and wreites necessary content to it 
     workbook = load_workbook(outputfile_name)
     term_sheet = workbook.worksheets[0]
     
     header_start_adding_row = 1
     header_start_adding_column = 2
     
     for header in extra_headers:
          term_sheet.cell(row=header_start_adding_row, column=header_start_adding_column).value = header
          header_start_adding_column += 1
          
     all_terms = onto.classes()
     non_deprecated_terms = []
     for term in all_terms:
          if term.deprecated == []:
               non_deprecated_terms.append(term)
               
     for term in non_deprecated_terms:
          content_for_file = []
          term_id = term.name
          content_for_file = [term_id]
          for term_ID_object in term_ann_properties_list:
               if eval(term_ID_object) != []:
                    term_ann = eval(term_ID_object)[0]
               else:
                    term_ann = ""
               term_headers = [term_ann, "", "", ""]
               content_for_file.extend(term_headers)
     
          term_sheet.append(content_for_file)
                     
     workbook.save(outputfile_name)
               
     
def main():
     current_working_directory = os.getcwd() #gets the current working directory path to use in the path for the new file below
     f = open(current_working_directory + "\\first_time_prep_input" + '.txt', 'r')
     lines = f.readlines()
     input_file_path = lines[0].strip()
     f.close()

     workbook = load_workbook(input_file_path)
     sheet = workbook.active
     
     owl_file_path = sheet['B1'].value
     anns_to_translate_file_path = sheet['B3'].value      
      
     ## Other variables ##
     excel_template_file = "templates/terms_for_review_template_file.xls" # relative path of the template .xlsx file used for creating the file of terms for review
     
     current_date = datetime.now().date() # obtains current date
     outputfile_name = "output/First_time/preparing_for_reviewers/First_time_terms_for_reviewers_" + str(current_date) + ".xls" # path of output file that will be generated
     
     ##### Functions #####
     copy_terms_for_review_template(excel_template_file, outputfile_name)
     write_term_annotations_to_excel(owl_file_path, anns_to_translate_file_path, outputfile_name)

    
if __name__ == '__main__':               
          main()