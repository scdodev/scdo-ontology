#program name: first_translation_using_files_from_reviewers.py

#25 May 2021
#Jade Hotchkiss

from tkinter import *
import tkinter as tk
from tkinter import messagebox

import os
from datetime import datetime

### creates the main program class
class run_program:    
    def __init__(self, window):
        
        #### Adds the main instruction/label to the window
        label1 = tk.Label(text="Please enter the required info below:",
                          fg="white",
                          bg="black",
                          width=100,
                          height=3)
        label1.place(x=0, y=0)
        label1.pack()

        ### Adds a space after the second menu
        frame = tk.Frame(window, height=20)
        frame.pack()
        
        ### Creates entry field for file path of file containing paths of input files
        entry_label1 = tk.Label(text="File path of file containing paths of input files:\n(template used: input_template_reviewed_files_paths)")
        entry_label1.pack()
        self.entry1 = tk.Entry(width=90)
        self.entry1.pack()

        ### Adds a space after the second menu
        frame = tk.Frame(window, height=20)
        frame.pack()
        
        ### Creates a run button and tells it to run the run_code() function when clicked
        run_button = tk.Button(text = "Run", justify = RIGHT, command = self.run_code, fg="black", bg="SlateGray3")
        run_button.pack()
        
        ### Adds a space after the second menu
        frame = tk.Frame(window, height=10)
        frame.pack()        

    ### Defines the run_code() function, which .
    def run_code(self):
        input_paths_file_path = self.entry1.get()
        
        if input_paths_file_path == "":
            messagebox.showerror(title="Error", message="Before you can continue, please ensure the entry field is completed.")      
        
        else:
            current_working_directory = os.getcwd() #gets the current working directory path to use in the path for the new file below

            current_date = datetime.now().date() # obtains current date to use in the name of the new fie below
                      
            writepath = current_working_directory + "\\sub_processes\\output\\First_time\\using_from_reviewers\\First_time_using_translations_input_file_paths_" + str(current_date) + '.txt'           
            
            newf = open(writepath,'w', encoding="utf8") # creates the output file using the name constructed above
            newf.write(input_paths_file_path) # writes the path provided by the user for the input file into the newly created txt file
        
            newf.close()
            
            os.chdir(current_working_directory +'\\sub_processes')
            
            print("This may take a minute or two...")
            
            os.system('python adding_translations_to_owl_GUI.py') # runs the program that extracts term annotations from reviewed files sent back from reviewers/translators and adds them to the owl file  
            
            window.destroy()        
            

window = tk.Tk() # creates the window
window.title("First Time Translating Ontology - Using Files from Reviewers") # sets the window's title
        
###runs Tkinter event loop (listens for button clicks or keypresses, and blocks code coming after from running until the window is closed)
run_program(window)
window.mainloop()