#Program name: adding_translations_to_owl_GUI.py

#Goes through files with reviewed term and property annotation translations and adds the translations to a specified owl file.

#8 June 2021
#Jade Hotchkiss

import os
from datetime import datetime

import shutil
from openpyxl import Workbook
from openpyxl import load_workbook

from owlready2 import *

### This function is run from within the next one
def adds_translations_to_ont(file_path, lang_tag, onto, index_ann_prop_label_to_ID, ann_props_file_path, obj_props_file_path, data_props_file_path, label_ann_prop_id, def_ann_prop_id):
     
     ### opens file of reviewed translations and adds translations to necessary python dictionaries
     workbook = load_workbook(file_path)
     term_sheet = workbook.worksheets[0]
     
     headers = []
     
     for header in term_sheet['1']:
          if header.value != "Term ID" and header.value != "" and header.value != None:
               headers.append(header.value)
               
     cleaned_headers = []
       
     for header in headers: # cleans headers so that they can be used in file names
          new_header = header.replace(" ", "_") # replaces spaces with "_"
          if ":" in new_header: # identifies annotation properties that contain a ":" and only continues below steps on such annotation properties
               new_header_list = new_header.split(':')  # splits headers on ":" 
               new_header = new_header_list[1] # retains second part of header (e.g. "rdfs:label" becomes "label")

          cleaned_headers.append(new_header) # adds cleaned header to list of cleaned headers
          
     cleaned_translated_annotations = []
     translated_annotations_position_dict = {} # dictionary in which an annotation's label is added as a key and its position in the header row as the value
     translation_position = 3
     translated_annotations = cleaned_headers[0::4] # creates a list of headers including the first untranslated annotation property and every 4th header after that
          
     for header in translated_annotations:
          header = header[8:] #removes first 8 digits of the header
          cleaned_translated_annotations.append(header)
          translated_annotations_position_dict[header] = translation_position
          translation_position += 4
     
     for translated_annotation in translated_annotations_position_dict:
          
          ann_position = translated_annotations_position_dict[translated_annotation]
               
          for row in term_sheet.rows:
               row_contents = []
               for cell in row:
                    row_contents.append(cell.value)
               if row_contents[0] != "Term ID":
                    translated_text = row_contents[ann_position]
                    if translated_text != "" and translated_text != None:
                         term_label = row_contents[1]
                         term_object = onto.search(label = term_label) # searches for the term object in the OWL file by using the term's label
                         term_attr = getattr(term_object[0], index_ann_prop_label_to_ID[translated_annotation]) # obtains the list of annotations ascribed to the term via the annotation property
                         term_attr.append(locstr(translated_text, lang = lang_tag)) # adds the translated annotation to the list along with the language tag provided
     
     ### opens file of reviewed translations of labels and definitions of object properties
     if obj_props_file_path != "":
          workbook2 = load_workbook(obj_props_file_path)
          obj_prop_sheet = workbook2.worksheets[0]      
          
          for row in obj_prop_sheet.rows:
               row_contents = []
               for cell in row:
                    row_contents.append(cell.value)
               if row_contents[0] != "Property ID":
                    prop_label = row_contents[1]
                    prop_def = row_contents[5]
                    print(prop_label)
                    prop_label_trans = row_contents[3]
                    prop_def_trans = row_contents[7]
                    prop_object = onto.search(label = prop_label) # searches for the property object in the OWL file by using the property's label
                    #if prop_object in onto.object_properties():
                    if prop_label != "" and prop_label != None:
                         prop_attr = getattr(prop_object[0], label_ann_prop_id) # obtains the list of annotations ascribed to the term via the annotation property
                         prop_attr.append(locstr(prop_label_trans, lang = lang_tag)) # adds the translated label to the list along with the language tag provided
                         print(prop_attr)
                    if prop_def != "" and prop_def_trans != None:
                    #if prop_def_trans != "" and prop_def_trans != None:
                         prop_attr = getattr(prop_object[0], def_ann_prop_id) # obtains the list of annotations ascribed to the term via the annotation property
                         prop_attr.append(locstr(prop_def_trans, lang = lang_tag)) # adds the translated label to the list along with the language tag provided  
                         print(prop_attr)
               
     ### opens file of reviewed translations of labels and definitions of annotation properties
     if ann_props_file_path != "":
          workbook3 = load_workbook(ann_props_file_path)
          ann_prop_sheet = workbook3.worksheets[0]    
          #print(onto.annotation_properties())
          for row in ann_prop_sheet.rows:
               row_contents = []
               for cell in row:
                    row_contents.append(cell.value)
               if row_contents[0] != "Property ID" and row_contents[0] != "" and row_contents[0] != None:
                    prop_label= row_contents[1]
                    prop_def = row_contents[5]
                    #print(prop_label)
                    prop_label_trans = row_contents[3]
                    prop_def_trans = row_contents[7]
                    prop_object = onto.search(label = prop_label) # searches for the property object in the OWL file by using the property's label
                    #print(prop_object)
                    #if prop_object in onto.annotation_properties():
                         #print(prop_object)
                    if prop_label != "" and prop_label != None:
                         #print()
                         prop_attr = getattr(prop_object[0], label_ann_prop_id) # obtains the list of annotations ascribed to the term via the annotation property
                         #print(prop_attr)
                         prop_attr.append(locstr(prop_label_trans, lang = lang_tag)) # adds the translated label to the list along with the language tag provided
                         #print(prop_attr)
                         #print()
                    if prop_def != "" and prop_def != None:
                    #if prop_def_trans != "" and prop_def_trans != None:
                         prop_attr = getattr(prop_object[0], def_ann_prop_id) # obtains the list of annotations ascribed to the term via the annotation property
                         prop_attr.append(locstr(prop_def_trans, lang = lang_tag)) # adds the translated label to the list along with the language tag provided
                              
     ### opens file of reviewed translations of labels and definitions of data properties
     if data_props_file_path != "":
          workbook4 = load_workbook(data_props_file_path)
          data_prop_sheet = workbook4.worksheets[0]    
     
          for row in data_prop_sheet.rows:
               row_contents = []
               for cell in row:
                    row_contents.append(cell.value)
               if row_contents[0] != "Property ID":
                    prop_label= row_contents[1]
                    prop_def = row_contents[5]
                    prop_label_trans = row_contents[3]
                    prop_def_trans = row_contents[7]
                    prop_object = onto.search(label = prop_label) # searches for the property object in the OWL file by using the property's label
               
                    #if prop_object in onto.data_properties():
                    if prop_label != "" and prop_label != None:
                         prop_attr = getattr(prop_object[0], label_ann_prop_id) # obtains the list of annotations ascribed to the term via the annotation property
                         prop_attr.append(locstr(prop_label_trans, lang = lang_tag)) # adds the translated label to the list along with the language tag provided
                    if prop_def != "" and prop_def != None:
                    #if prop_def_trans != "" and prop_def_trans != None:
                         prop_attr = getattr(prop_object[0], def_ann_prop_id) # obtains the list of annotations ascribed to the term via the annotation property
                         prop_attr.append(locstr(prop_def_trans, lang = lang_tag)) # adds the translated label to the list along with the language tag provided
     
     return onto

def extracts_translations_and_runs_function_to_add_them(terms_file_path, additional_anns_file_path, owl_file_path, ann_props_file_path, obj_props_file_path, data_props_file_path, primary_lang_tag, secondary_lang_tag, output_file_name): 
     
     from datetime import datetime
     
     cleaned_headers = [] # a list for storing all cleaned headers except the first cell's content   
     
     index_ann_prop_label_to_ID = {} # dictionary used for storing labels and IDs of additional annotation properties
     
     ### Opens input file to obtain ids and labels of annotation properties being translated
     anns_workbook = load_workbook(additional_anns_file_path)
     anns_sheet = anns_workbook.active
     
     label_ann_prop_id = anns_sheet['B2'].value
     def_ann_prop_id = anns_sheet['B3'].value
     
     for row in anns_sheet.iter_rows(min_row=2, min_col=2, max_col=3):
          annotation_ID = row[0].value
          annotation_label = row[1].value
          if annotation_ID !=  None and annotation_ID != "Annotation property ID": # ensures that the header row is skipped: # loops through the rows in the file               
               cleaned_label = annotation_label.replace(" ", "_") # replaces spaces in the label with "_"
               index_ann_prop_label_to_ID[cleaned_label] = annotation_ID # adds the "cleaned" label and term ID to the "index_ann_prop_label_to_ID" dictionary", as key and value, respectively 
     
     onto = get_ontology(owl_file_path).load() # loads the ontology as an "onto" object
     
     if isinstance(terms_file_path, list): # if there is more than one file for term annotations (i.e. more than one language being translated) runs adds_translations_to_ont() function 
          for (file_path, lang_tag, ann_props, obj_props, data_props)  in zip(terms_file_path, secondary_lang_tag, ann_props_file_path, obj_props_file_path, data_props_file_path):
               adds_translations_to_ont(file_path, lang_tag, onto, index_ann_prop_label_to_ID, ann_props, obj_props, data_props, label_ann_prop_id, def_ann_prop_id)
     
     else: #runs this if only one language is being translated and added to the ontology file
          adds_translations_to_ont(terms_file_path, secondary_lang_tag, onto, index_ann_prop_label_to_ID, ann_props_file_path, obj_props_file_path, data_props_file_path, label_ann_prop_id, def_ann_prop_id)
          
     current_date = datetime.now().date() # obtains current date
        
     ### Saves a new ontology file (rdf/xml format containing the edits made)
          
     onto.save(file = output_file_name, format = "rdfxml")


def main():
     from datetime import datetime
     ### Opens file containing path of file listing necessary file paths
     current_working_directory = os.getcwd() #gets the current working directory path to use in the path for the new file below
     current_date = datetime.now().date() # obtains current date to use in the name of the new file below     
     main_input_file = current_working_directory + "\\output\\First_time\\using_from_reviewers\\First_time_using_translations_input_file_paths_" + str(current_date) + '.txt'
     
     f1 = open(main_input_file, 'r').readlines() # Reads the file with the paths of input files
     
     
     ### writes input file path from line 2 to the "input_file_path" variable
     input_file_path=f1[0].strip()
     
     os.remove(main_input_file) # deletes the input file
     
     ### Opens input file to obtain necessary paths of other input files
     workbook = load_workbook(input_file_path)
     sheet = workbook.active   
     
     ### Obtains paths of various files and language tags to use
     owl_file_path = sheet['B1'].value
     
     terms_file_path = sheet['B3'].value
     if "," in terms_file_path:
          terms_file_path = terms_file_path.split(',')     
     
     ann_props_file_path = sheet['B5'].value
     if "," in ann_props_file_path:
          ann_props_file_path = ann_props_file_path.split(',')     
     
     obj_props_file_path = sheet['B7'].value
     if "," in obj_props_file_path:
          obj_props_file_path = obj_props_file_path.split(',')     
     
     data_props_file_path = sheet['B9'].value
     if "," in data_props_file_path:
          data_props_file_path = data_props_file_path.split(',')     
     
     primary_lang_tag = sheet['B11'].value
     if primary_lang_tag == "":
          print("No primary language tag provided in the input file.")
          
     secondary_lang_tag = sheet['B13'].value
     if "," in secondary_lang_tag:
          secondary_lang_tag = secondary_lang_tag.split(',')     
     if secondary_lang_tag == "":
          print("No secondary language tag provided in the input file.")
          
     additional_anns_file_path = sheet['B15'].value
     
     current_date = datetime.now().date() # obtains current date
          
     output_file_name = 'output/First_time/using_from_reviewers/ontology_with_translations_' + str(current_date) +".owl"
      
     
     ######## Functions ########
     extracts_translations_and_runs_function_to_add_them(terms_file_path, additional_anns_file_path, owl_file_path, ann_props_file_path, obj_props_file_path, data_props_file_path, primary_lang_tag, secondary_lang_tag, output_file_name)
          
if __name__ == '__main__':               
          main()