#extracting_annotation_translations_before_inclusion_GUI.py

#Goes through file with reviewed term annotation translations and generates separate .txt files of untranslated and translated annotations for each annotation property in the reviewed file.

#8 June 2021
#Jade Hotchkiss

import os
from datetime import datetime

import shutil
from openpyxl import Workbook
from openpyxl import load_workbook

### Global Lists ###
untranslated_headers = [] # a list for storing only cleaned headers of columns containing untranslated annotations

### Global Dictionaries ###
#IDs_untranslated_annotations_dict = {} # dictionary for storing term IDs as keys and lists of term's untranslated annotations as values
IDs_translated_annotations_dict = {} # dictionary for storing term IDs as keys and lists of term's translated annotations as values
index_ann_prop_label_to_ID = {} # dictionary for storing annotation property labels as keys and their IDs as values

### Creates a list of headers in the reviewed file, then creates a new list (cleaned_headers) where all headers with spaces have spaces replaced by "_" and headers containing ":" are split on ":" and only the second part of the header is kept. Then creates a list of all headers of untranslated annotation properties. Then creates 2 dictionaries, both with term IDs as keys, but one with the list of untranslated annotations as values and the other with translated annotations as values
def extracting_from_files(terms_file_path, additional_anns_file_path, terms_file_first_cell): 
     global untranslated_headers
     #global IDs_untranslated_annotations_dict
     global IDs_translated_annotations_dict 
     global index_ann_prop_label_to_ID
     cleaned_headers = [] # a list for storing all cleaned headers except the first cell's content   
     
     ### opens file of reviewed translations and adds translations to necessary python dictionaries
     workbook = load_workbook(terms_file_path)
     term_sheet = workbook.worksheets[0]     
     #f1 = open(terms_file_path, 'r', encoding="ISO-8859-1") 
     for row in f1: # loops through the rows in the file
          row = (row.strip('\n')).split('\t') # strips the row of line endings and splits the row on tabs
          if row [0] == terms_file_first_cell: # ensures only the header row is worked on here
               headers = []
               for header in row[1:]:
                    if header != "":
                         headers.append(header) # adds all headers except the first one to a list of headers
               print(headers)
               for header in headers: # cleans headers so that they can be used in file names
                    new_header = header.replace(" ", "_") # replaces spaces with "_"
                    if ":" in new_header: # identifies annotation properties that contain a ":" and only continues below steps on such annotation properties
                         new_header_list = new_header.split(':')  # splits headers on ":" 
                         new_header = new_header_list[1] # retains second part of header (e.g. "rdfs:label" becomes "label")
                    new_header = new_header[8:] #removes first 8 text of the new_header
                    cleaned_headers.append(new_header) # adds cleaned header to list of cleaned headers
               print(cleaned_headers)
               untranslated_headers = cleaned_headers[0::4] # creates a list of headers including the first untranslated annotation property and every 4th header after that
               print(untranslated_headers)
               
          elif row [0] != terms_file_first_cell: # identifies rows other than the header row
               term_ID = row[0] # assigns the content from the first cell in the row to the "term_ID" variable
               if term_ID != "":
                    untranslated_annotations = row[1::4] # creates a list of all untranslated annotations for each term
                    #IDs_untranslated_annotations_dict[term_ID] = untranslated_annotations # adds the term ID as key and list of untranslated annotations as value to the relevant dictionary
                    translated_annotations = row[3::4] # creates a list of all translated annotations for each term
                    print(untranslated_annotations)
                    print(translated_annotations)
                    IDs_translated_annotations_dict[term_ID] = translated_annotations # adds the term ID as key and list of translated annotations as value to the relevant dictionary
          
     f1.close() # closes file of reviewed translations         
     
     f2 = open(additional_anns_file_path, 'r', encoding="utf8") # opens file of additional annotations
     for row in f2: # loops through the rows in the file
          row = (row.strip('\n')).split('\t') # strips the row of line endings and splits the row on tabs
          ID = row[0] # assigns the content from the first cell in the row to the "ID" variable
          label = row[1] # assigns the content from the second cell in the row to the "label" variable
          cleaned_label = label.replace(" ", "_") # replaces spaces in the label with "_"
          index_ann_prop_label_to_ID[cleaned_label] = ID # adds the "cleaned" label and term ID to the "index_ann_prop_label_to_ID" dictionary", as key and value, respectively
     
     f2.close() # closes file containing annotation property labels and IDs
     
     #print(IDs_translated_annotations_dict)

### For each annotation property to be translated, writes all untranslated annotations (each row with a term ID and corresponding annotation) to a file and writes a separate file for all translated annotations 
def writing_extracted_annotations_to_separate_files(output_folder_name, index_file_name):
     global untranslated_headers
     global IDs_untranslated_annotations_dict
     global IDs_translated_annotations_dict
     global index_ann_prop_label_to_ID
          
     index_file_name = index_file_name + '.txt' # defines the name of the index file
     index_file = open(output_folder_name + "\\" + index_file_name,'w', encoding="utf8") # creates the index file in the same folder as the other output files will be created 
     
     header_position = 0 # sets the variable "header_position" to zero

     for header in untranslated_headers: # loops through annotations properties that have been translated       
          
          new_file_name_2 = "extracted_translated_" + header + '.txt' # defines the name of the file that will contain the translated annotations for the annotation property
          newf2 = open(output_folder_name +  "\\" + new_file_name_2,'w', encoding="utf8") # creates the new file
          newf2.write('ID' + '\t' + 'annotation' + '\n') # writes a header row to the file, first column with "ID" header and second column with "annotation" header
          for ID in IDs_translated_annotations_dict: # loops through all ontology terms  
               print(ID)
               annotations = IDs_translated_annotations_dict[ID] # obtains the list of translated annotations for the term
               print(annotations)               
               newf2.write(ID + '\t' + annotations[header_position] +'\n') # writes the term ID and corresponding translated annotation (the annotation in the same position in the list as the header) to the new file        
          print("Generated:" + new_file_name_2) # outputs on the screen the name of the file that has been generated
          newf2.close() # closes the new file  
          
          index_file.write(index_ann_prop_label_to_ID[header] + '\t' + new_file_name_2 +'\n') # writes the ID of the annotation property and the name of the file containing tranlsated annotations for that property
          
          header_position += 1 # increments the position of the header by 1 for the next loop
     
     index_file.close() # closes the generated index file

def main():
     ### Opens file containing path of file listing necessary file paths
     current_working_directory = os.getcwd() #gets the current working directory path to use in the path for the new file below
     current_date = datetime.now().date() # obtains current date to use in the name of the new fie below     
     
     f1 = open(current_working_directory + "\\output\\First_time\\using_from_reviewers\\First_time_using_translations_input_file_paths_" + str(current_date) + '.txt', 'r').readlines() # Reads the file with the paths of input files
     
     ### writes input file path from line 2 to the "input_file_path" variable
     input_file_path=f1[1].strip()
          
     ### Opens input file to obtain necessary paths of other input files
     f2 = open(input_file_path, 'r').readlines()
     
     second_line_content=f2[1].strip().split('\t')
     terms_file_path = second_line_content[1] # obtains path of txt file with reviewed term annotation translations
     
     additional_anns_file_path=f2[13].strip()
     # obtains path of the .txt file with the list of relevant annotation properties to be translated
     print('Additional anns file:')
     print(additional_anns_file_path)
          
     ## Other variables ##
     terms_file_first_cell = "Term ID" # content of first cell in header row of the file with reviewed term annotations
     index_file_name = "extracted_content_index_file" # name of the index file to be generated containing annotation property IDs and corresponding names of files containing translated annotations attributed to terms with them
     output_folder_name = current_working_directory + "\\output\\First_time\\using_from_reviewers\\extracted_annotations_files_" + str(current_date) # name of folder in which the files with extracted annotations will be created
     os.mkdir(output_folder_name)
       
     ######## Functions ########
     extracting_from_files(terms_file_path, additional_anns_file_path, terms_file_first_cell)
     writing_extracted_annotations_to_separate_files(output_folder_name, index_file_name)
     
if __name__ == '__main__':               
          main()