#program name: subsequent_translation_term_updates_needed_GUI.py

#30 August 2021
#Jade Hotchkiss

import shutil
from openpyxl import Workbook
from openpyxl import load_workbook

from owlready2 import *

import time
import os
from datetime import datetime

import zipfile
from zipfile import ZipFile

##### Creates empty lists and dictionaries for storing term IDs, labels and definitions #####
current_IDs_list = [] #list of all current term IDs
#current_ids_and_labels_dict = {} # dictionary of term IDs and labels
#current_ids_and_def_dict = {} # dictionary of term IDs and definitions

term_ann_properties_list = [] # list of annotation properties (in a "term.XXX" format, where XXX is the property ID) that that should be translated

main_file_extra_headers = []

new_terms_file_extra_headers = []

##### Goes through most recent ontology term annotations and populates the above lists #####
def current_terms(owl_file_path, anns_to_translate_file_path):
     onto = get_ontology(owl_file_path).load()  # loads the ontology as an "onto" object
     
     global current_IDs_list
     global term_ann_properties_list
     global main_file_extra_headers
     global new_terms_file_extra_headers
     #global current_ids_and_labels_dict
     #global current_ids_and_def_dict
     
     ann_to_translate_workbook = load_workbook(anns_to_translate_file_path)
     anns_sheet = ann_to_translate_workbook.active
     
     ### Iterates through rows in sheet, skipping first row and column, and adds content to above lists
     for row in anns_sheet.iter_rows(min_row=2, min_col=2, max_col=3):
          annotation_ID = row[0].value
          annotation_label = row[1].value
          if annotation_ID !=  None and annotation_ID != "Annotation property ID": # ensures that empty rows and the header row are skipped
               term_ann_properties_list.append("term." + str(annotation_ID)) # adds a string starting with "term." followed by the annotations's ID to the "term_ann_properties_list" list  
               
               main_file_extra_headers.append("previous " + annotation_label)
               main_file_extra_headers.append("previous " + annotation_label + " translation")
               main_file_extra_headers.append(annotation_label + " translations status")
               main_file_extra_headers.append("current " + annotation_label)
               main_file_extra_headers.append("current " + annotation_label + " translation")
               main_file_extra_headers.append("reviewed " + annotation_label + " translation")
               main_file_extra_headers.append("validation provided for current " + annotation_label)
               
               new_terms_file_extra_headers.append(annotation_label)
               
          all_terms = onto.classes()
          non_deprecated_terms = []
          
          for term in all_terms:
               if term.deprecated == []:
                    non_deprecated_terms.append(term)
          
          for term in non_deprecated_terms:
               term_id = term.name
               current_IDs_list.append(term_id)
               
previous_IDs_list = [] # list of all IDs of previously translated terms (terms in the second input file)
previous_ids_and_anns_dict = {} # dictionary of IDs and annotations for each term

##### Translated_terms function below goes through most recent reviewed file of a translation of the ontology and populates the above list and dictionary #####  
def translated_terms(term_translations_path):
     global previous_IDs_list
     global previous_ids_and_anns_dict
     
     workbook = load_workbook(term_translations_path)
     term_sheet = workbook.worksheets[0]
     
     ### Iterates through rows in the excel file with term translations, skipping first row, and adds content to above lists and dictionaries
     for row in term_sheet.iter_rows(min_row=2, min_col=1):
          term_ID = row[0].value     
          if term_ID not in previous_IDs_list: # if the term id is not already in the "previous_IDs_list" list...
               previous_IDs_list.append(term_ID) # adds it to the list
               anns_list = row[1:]
               clean_ann_list = []
               for ann in anns_list:
                    clean_ann_list.append(ann.value)
               previous_ids_and_anns_dict[term_ID] = clean_ann_list
     
new_terms_id_list = [] #lsit to which IDs of new onology terms will be added

def compare_versions():   
     global current_IDs_list
     global previous_IDs_list
     global new_terms_id_list
     
     for ID in current_IDs_list: # goes through IDs of terms in current/updated version of the ontology 
          if ID not in previous_IDs_list: #if the ID is NOT in the list of IDs in the previously translated terms...
               new_terms_id_list.append(ID) # add the term ID to the "new_terms_id_list" list

##### Writes the 2 output files #####
def write_translation_needed_files(owl_file_path, main_outputfile_template, main_outputfile, new_terms_outputfile_template, new_terms_outputfile):
     global new_terms_id_list
     global term_ann_properties_list
     global main_file_extra_headers
     global new_terms_file_extra_headers  

     ### Copies the template workbooks for terms and new terms to be reveiwed to the "output" folder and renames them as appropriate
     shutil.copy(main_outputfile_template, main_outputfile)
     shutil.copy(new_terms_outputfile_template, new_terms_outputfile)
     
     onto = get_ontology(owl_file_path).load()  # loads the ontology as an "onto" object
     
     all_terms = onto.classes()
     non_deprecated_terms = []
     for term in all_terms:
          if term.deprecated == []:
               non_deprecated_terms.append(term)
               
     workbook_1 = load_workbook(main_outputfile)
     main_output_sheet = workbook_1.active
     
     header_start_adding_row = 1 # sets the row in which content will be added
     header_start_adding_column = 2 # sets the column in which content will first be added
     
     for header in main_file_extra_headers: # writes the header row to the main output file
          main_output_sheet.cell(row=header_start_adding_row, column=header_start_adding_column).value = header
          header_start_adding_column += 1
     
     workbook_2 = load_workbook(new_terms_outputfile)
     new_terms_output_sheet = workbook_2.worksheets[0]
     
     header_start_adding_row = 1 # sets the row in which content will be added
     header_start_adding_column = 2 # sets the column in which content will first be added
     
     for header in new_terms_file_extra_headers: # writes the header row to the output file containing new terms
          new_terms_output_sheet.cell(row=header_start_adding_row, column=header_start_adding_column).value = header
          header_start_adding_column += 1
          
     ### loops through new terms and writes their relevant content to the output files
     for term_id in new_terms_id_list:     
          for term in non_deprecated_terms:
               if term.name == term_id:
                    content_for_main_outputfile = [term_id]
                    content_for_new_term_file = [term_id]
                    for term_object  in term_ann_properties_list:
                         if eval(term_object) != []:
                              if len(eval(term_object)) == 1:
                                   term_ann = eval(term_object)[0]
                              elif len(eval(term_object)) > 1:
                                   term_ann = " | ".join(eval(term_object))
                         else:
                              term_ann = ""
                         content_for_new_term_file.append(term_ann)
                              
                         if term_ann != "":
                              row_content = "-", "-", "auto-generated", term_ann, "", "", "replace me"
                                   
                         else:
                              row_content = "-", "-", "no annotation provided", term_ann, "", "NA", "NA"
                         content_for_main_outputfile.extend(row_content)
     
          new_terms_output_sheet.append(content_for_new_term_file)    
          main_output_sheet.append(content_for_main_outputfile)
          
     workbook_2.save(new_terms_outputfile)
          
     for term in non_deprecated_terms:
          if term.name not in new_terms_id_list:
               content_for_main_outputfile = [term.name]
                    
               ###below is different from first transltion update code
               prev_trans = previous_ids_and_anns_dict[term.name]
               last_anns = prev_trans[4::7]
               reviewed_trans = prev_trans[5::7]
               trans_validations = prev_trans[6::7]
                    
               for term_object, last_ann, last_translation, validation in zip(term_ann_properties_list, last_anns, reviewed_trans, trans_validations):
                    if eval(term_object) != []:
                         if len(eval(term_object)) == 1:
                              term_ann = eval(term_object)[0]
                         elif len(eval(term_object)) > 1:
                              term_ann = " | ".join(eval(term_object))
                    else:
                         term_ann = ""
                         
                    if term_ann == last_ann: # if the curren t annotation is the same as the last/previous annotation...
                         content_for_main_outputfile.append("same as current") # for "previous X" column
                         content_for_main_outputfile.append("same as current") # for "previous X translation" column
                         if validation == "edited but still need to be rechecked again":
                              content_for_main_outputfile.append("edited previously - needs re-checking")
                         else:
                              content_for_main_outputfile.append("translation complete")
                         content_for_main_outputfile.append(term_ann)
                         content_for_main_outputfile.append(last_translation)
                              
                         if validation == "edited but still need to be rechecked again":
                              content_for_main_outputfile.append("") # leaves reviewed column blank 
                              content_for_main_outputfile.append('replace me') # puts this in validation column
                         else:
                              content_for_main_outputfile.append("NA")
                              content_for_main_outputfile.append("NA")
                    else:
                         content_for_output_row = last_ann, last_translation, 'needs updating', term_ann, 'replace me', '', 'replace me'
                         content_for_main_outputfile.extend(content_for_output_row)
                    
               main_output_sheet.append(content_for_main_outputfile)
               
     workbook_1.save(main_outputfile)           
     
def main():
     current_working_directory = os.getcwd() #gets the current working directory path to use in the path for the new file below
     f = open(current_working_directory + "\\update_prep_input" + '.txt', 'r')
     lines = f.readlines()
     input_file_path = lines[0].strip()
     f.close()
     os.remove(current_working_directory + "\\update_prep_input" + '.txt')
     
     workbook = load_workbook(input_file_path)
     sheet = workbook.active
     
     owl_file_path = sheet['B1'].value
     anns_to_translate_file_path = sheet['B3'].value
     term_translations_path = sheet['B5'].value
     
     ## Other variables ##
     current_date = datetime.now().date() # obtains current date
     
     main_outputfile_template = "templates/first_update_main_outputfile_template.xls" # relative path of the template .xlsx file used for creating the file of terms for review
     
     main_outputfile = "output/Subsequent_translation_update/preparing_for_reviewers/subsequent_update_main_outputfile_" + str(current_date) + ".xls" # path (including file name and extension) of the program's main output file
     
     new_terms_outputfile_template = "templates/first_update_new_terms_outputfile_template.xls" # relative path of the template .xlsx file used for creating the file of new terms for automtranslation and then review
     
     new_terms_outputfile = "output/Subsequent_translation_update/preparing_for_reviewers/subsequent_update_new_terms_outputfile_" + str(current_date) + ".xls" # path (including file name and extension) of the output file containing new terms to be auto-translated
     
     #####Functions#####
     current_terms(owl_file_path, anns_to_translate_file_path)
     
     translated_terms(term_translations_path)
     
     compare_versions()
     
     write_translation_needed_files(owl_file_path, main_outputfile_template, main_outputfile, new_terms_outputfile_template, new_terms_outputfile)

if __name__ == '__main__':               
          main()     