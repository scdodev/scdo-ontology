#Program name: first_translation_property_updates_needed_GUI.py

# Program used during the first update of an ontology translation, that goes through an untranslated owl file and extracts the labels and descriptions of all object, annotation and data properties, generating three separate files with this information.

#5 July 2021
#Jade Hotchkiss

from openpyxl import Workbook
from openpyxl import load_workbook

from owlready2 import *

import time
import os
from datetime import datetime

### creates variables to be used for IDs of the ontology's label and definition annotations properties
label_id = ""
def_id = ""

##### Creates empty lists and dictionaries for storing property IDs, labels and definitions #####
current_property_IDs_list = [] #list of all current term IDs

current_ann_prop_ids_and_labels_dict = {} # dictionary of term IDs and labels for annotation properties
current_ann_prop_ids_and_def_dict = {} # dictionary of term IDs and definitions for annotation properties

current_obj_prop_ids_and_labels_dict = {} # dictionary of term IDs and labels for object properties
current_obj_prop_ids_and_def_dict = {} # dictionary of term IDs and definitions for object properties

current_data_prop_ids_and_labels_dict = {} # dictionary of term IDs and labels for data properties
current_data_prop_ids_and_def_dict = {} # dictionary of term IDs and definitions for data properties

##### Goes through most recent ontology term annotations and populates the above list and dictionaries #####
def current_props(owl_file_path, anns_to_translate_file_path):
     global label_id
     global def_id
     global current_property_IDs_list
     global current_ann_prop_ids_and_labels_dict
     global current_ann_prop_ids_and_def_dict
     global current_obj_prop_ids_and_labels_dict
     global current_obj_prop_ids_and_def_dict
     global current_data_prop_ids_and_labels_dict
     global current_data_prop_ids_and_def_dict
     
     onto = get_ontology(owl_file_path).load()  # loads the ontology as an "onto" object
     
     workbook = load_workbook(anns_to_translate_file_path)
     sheet = workbook.active
     
     label_id = sheet['B2'].value
     def_id = sheet['B3'].value
               
     for ann_property in onto.annotation_properties(): # loops through annotation property objects in the OWL file
          prop_ID = ann_property.name # obtains the ID of the annotation property
          current_property_IDs_list.append(prop_ID)
          
          prop_label_object = "ann_property." + label_id

          if eval(prop_label_object) != []: # if the term's list of labels is not empty...             
               label = eval(prop_label_object)[0] # obtains the first label in the list of labels (this assumes there is only one label)
               current_ann_prop_ids_and_labels_dict[prop_ID] = [label]          
          prop_def_object = "ann_property." + def_id
          if eval(prop_def_object) != []: # if the term's list of definitions is not empty...
               definition = eval(prop_def_object)[0] # obtains the first label in the list of labels (this assumes there is only one label)
               current_ann_prop_ids_and_def_dict[prop_ID] = [definition]          
     for obj_property in onto.object_properties(): # loops through object property objects in the OWL file
          prop_ID = obj_property.name # obtains the ID of the object property
          current_property_IDs_list.append(prop_ID)
          
          prop_label_object = "obj_property." + label_id
          if eval(prop_label_object) != []: # if the term's list of labels is not empty...
               label = eval(prop_label_object)[0] # obtains the first label in the list of labels (this assumes there is only one label)
               current_obj_prop_ids_and_labels_dict[prop_ID] = [label]          
          prop_def_object = "obj_property." + def_id
          if eval(prop_def_object) != []: # if the term's list of definitions is not empty...
               definition = eval(prop_def_object)[0] # obtains the first label in the list of labels (this assumes there is only one label)
               current_obj_prop_ids_and_def_dict[prop_ID] = [definition]          
     for data_property in onto.data_properties(): # loops through data property objects in the OWL file
          prop_ID = data_property.name # obtains the ID of the object property
          current_property_IDs_list.append(prop_ID)
          
          prop_label_object = "data_property." + label_id
          if eval(prop_label_object) != []: # if the term's list of labels is not empty...
               label = eval(prop_label_object)[0] # obtains the first label in the list of labels (this assumes there is only one label)
               current_data_prop_ids_and_labels_dict[prop_ID] = [label]          
          prop_def_object = "data_property." + def_id
          if eval(prop_def_object) != []: # if the term's list of definitions is not empty...
               definition = eval(prop_def_object)[0] # obtains the first label in the list of labels (this assumes there is only one label)
               current_data_prop_ids_and_def_dict[prop_ID] = [definition]          

##### Translated_props function below goes through most recent reviewed file of a translation of the ontology and populates the above lists and dictionaries #####  
def translated_props(translated_props_files, updated_props_output_files, extra_info_files, removed_prop_files):
     global current_property_IDs_list
     global current_ann_prop_ids_and_labels_dict
     global current_ann_prop_ids_and_def_dict
     global current_obj_prop_ids_and_labels_dict
     global current_obj_prop_ids_and_def_dict
     global current_data_prop_ids_and_labels_dict
     global current_data_prop_ids_and_def_dict     
     
     property_type_order = 0 #sets a variable to use for the property type variable. In the for loop below it will assume if property_type_order = 0 it's working with annotation properties, if 1, object properties, if 2, data properties
     
     for prop_file, output_file, extra_info_file, removed_props_file in zip(translated_props_files, updated_props_output_files, extra_info_files, removed_prop_files):
          
          workbook = load_workbook(prop_file)
          props_sheet = workbook.active
     
          old_prop_dict = {} # creates dictionary where previously extracted property IDs will be used as keys and labels and definitions will be stored as values
          
          old_prop_labels_list = [] # creates an empty list to which the labels of old properties are added
          
          updated_prop_dict = {} # creates dictionary where newly extracted object property IDs will be used as keys and labels and definitions will be stored as values
          
          ### Iterates through rows in the excel file with term translations, skipping first row, and adds content to above lists and dictionaries
          for row in props_sheet.iter_rows(min_row=2, min_col=1):
               prop_ID = row[0].value
               prop_label = row[1].value
               if len(row) > 2:
                    prop_definition = row[5].value # assigns content of third cell in the row to a "prop_definition" variable
               else:
                    prop_definition = ""
               old_prop_dict[prop_ID] = [prop_label, prop_definition] # adds the property ID as a key to the "old_ann_prop_dict" dictionary and its label and definiitons as values
               old_prop_labels_list.append(prop_label)
     
          if property_type_order == 0:
               prop_type = "annotation"

               current_prop_ids_and_labels_dict = current_ann_prop_ids_and_labels_dict
               
               current_prop_ids_and_def_dict = current_ann_prop_ids_and_def_dict
          
          elif property_type_order == 1:
               prop_type = "object"              
               
               current_prop_ids_and_labels_dict = current_obj_prop_ids_and_labels_dict
               
               current_prop_ids_and_def_dict = current_obj_prop_ids_and_def_dict
               
          elif property_type_order == 2:
               prop_type = "data"
               
               current_prop_ids_and_labels_dict = current_data_prop_ids_and_labels_dict
               
               current_prop_ids_and_def_dict = current_data_prop_ids_and_def_dict           
          
          removed_properties = [] # creates empty list to which IDs of removed annotation propertes will be added
          for prop in old_prop_dict:
               if prop not in current_prop_ids_and_labels_dict:
                    removed_properties.append(prop) # adds the ID of the annotation property to the list of removed annotation properties
                    
          if len(removed_properties) > 0: # if there are 1 or mor properties to be removed...
               newf_removed_props =  open(removed_props_file,'w', encoding="UTF-8") # creates file to which removed annotation properties will be written, if there are any.
               newf_removed_props.write("Properties removed:" + '\n') # writes a header row to the output file for properties to be removed
               for property_id in removed_properties: # loops through annotation properties to be removed

                    newf_removed_props.write(str(property_id) + '\t' + str(old_prop_dict[property_id][0]) + '\n') # writes the ID of the property and its label to the output file
               newf_removed_props.close()     
          
          prop_ann_statuses = {} # an empty dictionary to which statuses of labels and definitions of annotation properties will be added (object property ID as key and labels and definitions stauses (updated, same or new) as values
          updated = 0
          new = 0          
          
          for prop in current_prop_ids_and_labels_dict:
               if prop in old_prop_dict:
                    if current_prop_ids_and_labels_dict[prop][0] != old_prop_dict[prop][0]:
                         label = "updated"
                         updated += 1
                    else:
                         label = "same"

                    if prop in current_prop_ids_and_def_dict:
                         if current_prop_ids_and_def_dict[prop][1] != old_prop_dict[prop][1]:
                              definition = "updated"
                              updated += 1
                         else:
                              definition = "same"

               else:
                    label = "new"
                    definition = "new"
                    new += 1
                    
               prop_ann_statuses[prop] = [label, definition]
          
          if updated > 0 or new > 0: # if there are 1 or more new or updated annotations for the properties...
               newf_extra_info = open(extra_info_file,'w', encoding="UTF-8") # creates the output file for updated propertie
               newf_extra_info.write("These 'new' properties may have just had their urls updated. Check they're not in the 'removed_annotation_properties' file:" + '\n')
               
               newf_updated_anns= open(output_file,'w', encoding="UTF-8") # creates the output file for updated properties
               
               wb = Workbook()
               ws1 = wb.active
               ws1.title = "updated annotations"
               
               header_list = "ID", "New or updated label?", "New/updated label", "New or updated description?", "New/updated description"
               
               header_start_adding_column = 1
               
               for header in header_list:
                    ws1.cell(row=1, column = header_start_adding_column).value = header
                    header_start_adding_column += 1 
                    #header_start_adding_column += 1               
               
               #newf_updated_anns.write("ID" + '\t' + "New or updated label?"+ '\t' + "New/updated label" + '\t' + "Translated label" + '\t' + "Reviewed translated label" + '\t' + "New or updated description?" + '\t' + "New/updated description" + '\t' + "Translated description" + '\t' + "Reviewed translated description" + '\n')
               
               for prop in prop_ann_statuses: # loops through dictionary of statuses of property annotations
                    if prop_ann_statuses[prop][0] == "new": # if the property's label is new...
                         for_file = str(prop), 'New label', str(current_prop_ids_and_labels_dict[prop][0]),"New description", str(current_prop_ids_and_def_dict[ann_prop][0])
                         #ws1.append(for_file)
                         
                         #newf_updated_anns.write(str(prop)  + '\t' + 'New label' + '\t' + str(current_prop_ids_and_labels_dict[prop][0]) + '\t'  + "" + '\t' + "" + '\t'+ "New description" + '\t' + str(current_prop_ids_and_def_dict[ann_prop][0]) + '\t' + "" + '\t' + "" + '\n') # writes the property's ID,  label and definition and additional columns to the output file of updated property annotations
                         if current_prop_ids_and_labels_dict[prop][0] in old_prop_dict:
                              newf_extra_info.write(prop + '\t' + current_prop_ids_and_labels_dict[prop][0] + '\n')
                    elif prop_ann_statuses[prop][0] == "updated": # if the property's label is updated...
                         for_file = str(prop), 'Updated label', str(current_prop_ids_and_labels_dict[ann_prop][0])
                         
                         #newf_updated_anns.write(str(prop) + '\t' + 'Updated label' + '\t' + str(current_prop_ids_and_labels_dict[ann_prop][0])  + '\t' + "" + '\t' + "" + '\t') # writes the property's ID and label to the output file of updated property annotations
                         if prop_ann_statuses[prop][1] == "updated": # if the property's definition is updated...
                              add_to_for_file = "Updated description", str(current_prop_ids_and_def_dict[prop][0])
                              
                              #newf_updated_anns.write("Updated description" + '\t' + str(current_prop_ids_and_def_dict[prop][0]) + '\t' + "" + '\t' + "" + '\n') # writes the updated definition to the output file of updated property annotations
                         else: # if the property's definition is NOT updated (same as old version)...
                              add_to_for_file = "", 'NA'
                              #newf_updated_anns.write("" + '\t' + 'NA' + '\t' + "" + '\t' + "" + '\n') # leaves the description status column blank and writes "NA" to the description column
                         for_file.extend(add_to_for_file)
                    elif prop_ann_statuses[prop][0] == "same": # if the property's label is NOT updated (same as old version)...
                         if prop_ann_statuses[prop][1] != "same": # if the property's definition is updated or new...
                              if prop_ann_statuses[prop][1] == "new":
                                   if current_prop_ids_and_def_dict[prop] != []:
                                        for_file = str(prop), "NA", "", "New description", str(current_prop_ids_and_def_dict[prop][0])
                                   
                                        #newf_updated_anns.write(str(prop) + '\t' + "NA" + '\t' + "" + '\t' + "" + '\t' + "" + '\t'+  "New description" + '\t' + str(current_prop_ids_and_def_dict[prop][0]) + '\t' + "" + '\t' + "" + '\n') # writes the property's ID, "NA" and the new or updated definition to the output file
                                   else:
                                        for_file = str(prop), "NA", "", "No description", ""
                                        #newf_updated_anns.write(str(prop) + '\t' + "NA" + '\t' + "" + '\t' + "" + '\t' + "" + '\t'+  "No description" + '\t' + "" + '\t' + "" + '\t' + "" + '\n') # writes the property's ID, "NA" and the new or updated definition to the output file
                                        
                              elif prop_ann_statuses[prop][1] == "updated":
                                   if prop in current_prop_ids_and_def_dict:
                                        for_file = str(prop), "NA", "", "Updated description", str(current_prop_ids_and_def_dict[prop][0])
                                        
                                        #newf_updated_anns.write(str(prop) + '\t' + "NA" + '\t' + "" + '\t' + "" + '\t' + "" + '\t'+  "Updated description" + '\t' + str(current_prop_ids_and_def_dict[prop][0]) + '\t' + "" + '\t' + "" + '\n') # writes the property's ID, "NA" and the new or updated definition to the output file
                                   else:
                                        for_file = str(prop), "NA", "", "Description removed", ""
                                        
                                        #newf_updated_anns.write(str(prop) + '\t' + "NA" + '\t' + "" + '\t' + "" + '\t' + "" + '\t'+  "Description removed" + '\t' + "" + '\t' + "" + '\t' + "" + '\n') # writes the property's ID, "NA" and the new or updated definition to the output file
                    ws1.append(for_file) 
               wb.save(filename = output_file)       
               #newf_updated_anns.close() # closes the output file of updated property annotations
               
          else:
               message = "No new " + prop_type + " properties and no updates made to " + prop_type + " property annotations, thus no file generated for translation updates."
               
               print(message)          
               
          property_type_order +=1
     
def main():
     current_working_directory = os.getcwd() #gets the current working directory path to use in the path for the new file below
     f = open(current_working_directory + "\\update_prep_input" + '.txt', 'r')
     lines = f.readlines()
     input_file_path = lines[0].strip()
     type_of_update = lines[1].strip()     
     f.close()

     workbook = load_workbook(input_file_path)
     sheet = workbook.active
     
     owl_file_path = sheet['B1'].value
     anns_to_translate_file_path = sheet['B3'].value
     ann_props_file_path = sheet['B7'].value
     obj_props_file_path = sheet['B9'].value
     data_props_file_path = sheet['B11'].value
     
     translated_props_files = [ann_props_file_path, obj_props_file_path, data_props_file_path]
               
     ## Other variables ##
     if type_of_update == "first update":
          output_folder_location = "output/First_translation_update/preparing_for_reviewers/"
     
     elif type_of_update == "subsequent update":
          output_folder_location = "output/Subsequent_translation_update/preparing_for_reviewers/"
          
     outputfile_updated_ann_props_path = output_folder_location + "updated_ann_prop_annotations.xls"
     
     outputfile_updated_ann_props_extra_info_file_path = output_folder_location + "extra_info_about_new_ann_props.txt"     
     
     outputfile_updated_object_props_path = output_folder_location + "updated_obj_prop_annotations.xls"
          
     outputfile_updated_object_props_extra_info_file_path = output_folder_location + "extra_info_about_new_obj_props.txt"
     
     outputfile_updated_data_props_path = output_folder_location + "updated_data_prop_annotations.xls"
     
     outputfile_updated_data_props_extra_info_file_path = output_folder_location + "extra_info_about_new_data_props.txt"   
     
     updated_props_output_files = [outputfile_updated_ann_props_path, outputfile_updated_object_props_path, outputfile_updated_data_props_path]
     
     extra_info_files = [outputfile_updated_ann_props_extra_info_file_path, outputfile_updated_object_props_extra_info_file_path, outputfile_updated_data_props_extra_info_file_path]
     
     removed_ann_props_file_path = output_folder_location + "removed_annotation_properties.txt" 
     
     removed_obj_props_file_path = output_folder_location + "removed_object_properties.txt"
        
     removed_data_props_file_path = output_folder_location + "removed_data_properties.txt"
     
     removed_prop_files = [removed_ann_props_file_path, removed_obj_props_file_path, removed_data_props_file_path]
     
     #####Functions#####
     current_props(owl_file_path, anns_to_translate_file_path)
     translated_props(translated_props_files, updated_props_output_files, extra_info_files, removed_prop_files)

if __name__ == '__main__':               
          main()