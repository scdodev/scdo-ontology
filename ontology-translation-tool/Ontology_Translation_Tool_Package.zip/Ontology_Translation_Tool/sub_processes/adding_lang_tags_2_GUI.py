#adding_lang_tags_2_GIU.py
#Program that goes through an owl file that does not have language tags and adds a language tag to all annotations made by a provided list of annotation properties (does labels by default, but should still be in the list for other programs to use) and to labels of ALL annotation properties and object properties (except "rdfs:" annotation properties).

#Errors:
#       If this error occurs: "builtins.ModuleNotFoundError: No module named 'owlready2'" --> run "pip install Owlready2" in cmd
#       If you still get an error, run this command in the anaconda prompt: "conda install -c conda-forge owlready2"
#       If you still get an error, run this command in anaconda prmpt: "pip install pysqlite3"
#       If you still get an error, go to "https://www.sqlite.org/download.html" and download the appropriate dll zip file and add to "C:\Users\YOURUSER\Anaconda3\DLLs"

#23 June 2021
#Jade Hotchkiss

from owlready2 import *

from openpyxl import Workbook
from openpyxl import load_workbook

import os
from datetime import datetime 

##### Adds language tags to OWL/RDF file #####
def adding_language_tags(owl_file_path, file_with_list_of_annotations, outputfile_name, lang_tag):
     
     onto = get_ontology(owl_file_path).load() # loads the ontology as an "onto" object
     workbook = load_workbook(file_with_list_of_annotations)
     sheet = workbook.active     
     
     term_ann_properties_list = [] # list of annotation properties (in a "term.XXX" format, where XXX is the property ID) that should have tags added to term annotations made via them
     
     ### Iterates through rows in sheet, skipping first row and column, and adds content to above lists
     for row in sheet.iter_rows(min_row=2, min_col=2, max_col=3):
          annotation_ID = row[0].value
          if annotation_ID !=  None:
               if annotation_ID not in term_ann_properties_list: # if the annotation property ID is not already in the "term_ann_properties_list" list...
                    term_ann_properties_list.append("term." + str(annotation_ID)) # adds a string starting with "term." followed by the annotations's ID to the "term_ann_properties_list" list
                    
     ### Adds language tag to all annotations made by the annotation properties in the 2nd input file
     for term in list(onto.classes()): # loops through the list of classes in the ontology
          if term.deprecated == []: # ensures that only terms that are not deprecated have the language tags added
                              
               for term_property in term_ann_properties_list:
                    if eval(term_property) != []: # ensures that the list of annotations made via the annotation property for the term is not empty before continueing...
                         if len(eval(term_property)) == 1: # if the list of annotations made via the annotation property for the term only has one item/annotation...
                              annotation = eval(term_property)[0] # saves the item/annotation using the "annotation" variable
                              eval(term_property).remove(str(eval(term_property)[0])) # removes annotation from OWL file 
                              eval(term_property).append(locstr(annotation, lang = lang_tag)) # re-adds annotation with the language tag included
                         
                         elif len(eval(term_property)) > 1: # if the list of annotations made via the annotation property for the term has more than one item/annotation...
                              for i in range(len(eval(term_property))): # loops through each item/annotation for the term
                                   annotation = eval(term_property)[0] # saves the item/annotation using the "annotation" variable
                                   eval(term_property).remove(str(eval(term_property)[0])) # removes annotation from OWL file
                                   eval(term_property).append(locstr(annotation, lang = lang_tag)) # re-adds annotation with the language tag included
     
     label_property_id = sheet['B2'].value
     definition_property_id = sheet['B3'].value
     
     ### Adds language tag to labels of ALL annotation properties in the ontology (because of a bug, rdfs:label and rdfs:comment are not included in the list obtained when running onto.annotation_properties(). Language tags must be added to them manually!
     for ann_property in onto.annotation_properties(): # loops through the anotation property objects in the ontology
          ann_property_label_object = "ann_property." + label_property_id
          ann_property_def_object = "ann_property." + definition_property_id
          if eval(ann_property_label_object)!= []:
          # if the annotation property's list of labels is not empty...
               label = eval(ann_property_label_object)[0] # saves the label using the "label" variable
               eval(ann_property_label_object).remove(str(eval(ann_property_label_object)[0])) # removes label from OWL file
               label_object = eval(ann_property_label_object)
               label_object.append(locstr(label, lang = lang_tag)) # re-adds it with the language tag included
          
          if eval(ann_property_def_object)!= []:
          # if the annotation property's list of definition is not empty...
               definition = eval(ann_property_def_object)[0] # saves the description using the "definition" variable
               eval(ann_property_def_object).remove(eval(ann_property_def_object)[0]) # removes definition from OWL file
               def_object = eval(ann_property_def_object)
               def_object.append(locstr(definition, lang = lang_tag)) # re-adds it with the language tag included
               
     ### Adds language tag to labels of ALL object properties in the ontology
     for obj_property in onto.object_properties(): # loops through the object property objects in the ontology
          obj_property_label_object = "obj_property." + label_property_id
          obj_property_def_object = "obj_property." + definition_property_id
          
          if eval(obj_property_label_object) != []: # if the object property's list of labels is not empty...
               label = eval(obj_property_label_object)[0] # saves the label using the "label" variable
               eval(obj_property_label_object).remove(str(eval(obj_property_label_object)[0])) # removes label from OWL file
               label_object = eval(obj_property_label_object)
               label_object.append(locstr(label, lang = lang_tag)) # re-adds it with the language tag included
               
          if eval(obj_property_def_object) != []: # if the object property's list of definition is not empty...
               definition = eval(obj_property_def_object)[0] # saves the definition using the "definition" variable
               eval(obj_property_def_object).remove(str(eval(obj_property_def_object)[0])) # removes definition from OWL file
               def_object = eval(obj_property_def_object)
               def_object.append(locstr(definition, lang = lang_tag)) # re-adds it with the language tag included
               
     ### Adds language tag to labels of ALL data properties in the ontology
     for data_property in onto.data_properties(): # loops through the anotation property objects in the ontology   
          data_property_label_object = "data_property." + label_property_id
          data_property_def_object = "data_property." + definition_property_id               
          if eval(data_property_label_object) != []: # if the annotation property's list of labels is not empty...
               label = eval(data_property_label_object)[0] # saves the label using the "label" variable
               eval(data_property_label_object).remove(str(eval(data_property_label_object)[0])) # removes label from OWL file
               label_object = eval(data_property_label_object)
               label_object.append(locstr(label, lang = lang_tag)) # re-adds it with the language tag included
                    
          if eval(data_property_def_object) != []: # if the annotation property's list of definition is not empty...
               definition = eval(data_property_def_object)[0] # saves the description using the "definition" variable
               eval(data_property_def_object).remove(eval(data_property_def_object)[0]) # removes definition from OWL file
               def_object = eval(data_property_def_object)
               def_object.append(locstr(definition, lang = lang_tag)) # re-adds it with the language tag included     
     
     ### Saves a new ontology file (rdfxml format containing the edits made) using the outputfile name provided     
     onto.save(file = outputfile_name, format = "rdfxml")

def main():
     current_working_directory = os.getcwd() #gets the current working directory path to use in the path for the new file below
     f = open(current_working_directory + "\\update_prep_input" + '.txt', 'r')
     lines = f.readlines()
     input_file_path = lines[0].strip()
     f.close()

     workbook = load_workbook(input_file_path)
     sheet = workbook.active     
     
     owl_file_path = sheet['B1'].value
     anns_to_translate_file_path = sheet['B3'].value
     primary_lang_tag = sheet['B15'].value
     
     ## Other variables ##
     current_date = datetime.now().date() # obtains current date to use in the name of the new fie below
     outputfile_name = "output/First_translation_update/preparing_for_reviewers/owl_with_primary_language_tag_added_" + str(current_date) +".rdf" # name of output file (rdf file created with language tags added)
       
     #####Functions#####
     adding_language_tags(owl_file_path, anns_to_translate_file_path, outputfile_name, primary_lang_tag)
         
if __name__ == '__main__':               
          main()