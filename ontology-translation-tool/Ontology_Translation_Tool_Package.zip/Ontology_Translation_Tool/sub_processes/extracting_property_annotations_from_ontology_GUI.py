#Program name: extracting_property_annotations_from_ontology_GUI.py

# Program that goes through an untranslated owl file and extracts the labels and descriptions of all object, annotation and data properties, generating three separate files with this information.

#14 May 2021
#Jade Hotchkiss

from owlready2 import *

import os
from datetime import datetime

import shutil
from openpyxl import Workbook
from openpyxl import load_workbook

### Copies the template workbooks for annotation, object and data properties to be reveiwed to the "output" folder and renames it as appropriate
def copy_properties_for_review_templates(ann_props_template_file, obj_props_template_file, data_props_template_file, ann_props_output_file, obj_props_output_file, data_props_output_file):
     shutil.copy(ann_props_template_file, ann_props_output_file)
     shutil.copy(obj_props_template_file, obj_props_output_file)
     shutil.copy(data_props_template_file, data_props_output_file)

##### Extracts labels and descriptions of annotation and object properties and writes them to their respective output files
def get_annotations_from_owl_file(owl_file_path, anns_to_translate_file_path, ann_props_output_file, obj_props_output_file, data_props_output_file):
     onto = get_ontology(owl_file_path).load()  # loads the ontology as an "onto" object
     
     workbook1 = load_workbook(anns_to_translate_file_path) # opens the file with annotations to be translated for the ontology
     anns_sheet = workbook1.worksheets[0]
     label_id = anns_sheet["B2"].value
     def_id = anns_sheet["B3"].value
          
     workbook2 = load_workbook(ann_props_output_file)
     properties_sheet = workbook2.worksheets[0]     
     
     for ann_property in onto.annotation_properties(): # loops through annotation property objects in the OWL file
          ID = ann_property.name # obtains the ID of the annotation property
          new_label_id = ("ann_property." + str(label_id))
          if eval(new_label_id) != []: # if the annotation property's list of labels is not empty...
               #print(eval(new_label_id))
               label = eval(new_label_id)[0] # obtains the first label in the list of labels (this assumes there is only one label)
          
          new_def_id = ("ann_property." + str(def_id))    
          if eval(new_def_id) != []: # if the annotation property's list of descriptions is not empty...
               #print(eval(new_def_id))
               definition = eval(new_def_id)[0] # obtains the first definition in the list of definitions (this assumes there is only one definition) 
               
          content_for_file = [ID, label, "", "", "", definition]
          properties_sheet.append(content_for_file)
          label = ""
          definition = ""          
     
     workbook2.save(ann_props_output_file)        
     
     workbook3 = load_workbook(obj_props_output_file)
     properties_sheet = workbook3.worksheets[0]  
     
     for obj_property in onto.object_properties(): # loops through object property objects in the OWL file
          ID = obj_property.name # obtains the ID of the object property
          new_label_id = ("obj_property." + str(label_id))
          if eval(new_label_id) != []: # if the object property's list of labels is not empty...
               label = eval(new_label_id)[0] # obtains the first label in the list of labels (this assumes there is only one label)
          
          new_def_id = ("obj_property." + str(def_id)) 
          if eval(new_def_id) != []: # if the object property's list of descriptions is not empty...
               definition = eval(new_def_id)[0] # obtains the first definition in the list of definitions (this assumes there is only one definition) 
     
          content_for_file = [ID, label, "", "", "", definition]
          properties_sheet.append(content_for_file)
          label = ""
          definition = ""

     workbook3.save(obj_props_output_file)
     
     workbook4 = load_workbook(data_props_output_file)
     properties_sheet = workbook4.worksheets[0]     
     
     for data_property in onto.data_properties(): # loops through data property objects in the OWL file
          ID = data_property.name # obtains the ID of the data property
          new_label_id = ("data_property." + str(label_id))
          if eval(new_label_id) != []: # if the data property's list of labels is not empty...
               label = eval(new_label_id)[0] # obtains the first label in the list of labels (this assumes there is only one label)
          
          new_def_id = ("data_property." + str(def_id))     
          if eval(new_def_id) != []: # if the data property's list of descriptions is not empty...
               definition = eval(new_def_id)[0] # obtains the first definition in the list of definitions (this assumes there is only one definition) 
               
          content_for_file = [ID, label, "", "", "", definition]
          properties_sheet.append(content_for_file)
          label = ""
          definition = ""          
     
     workbook4.save(data_props_output_file)               
          
def main():
     ### Opens output file from previous window and reads content
     current_working_directory = os.getcwd() #gets the current working directory path to use in the path for the new file below
     f = open(current_working_directory + "\\first_time_prep_input" + '.txt', 'r')
     lines = f.readlines()
     input_file_path = lines[0].strip()
     f.close()
     os.remove(current_working_directory + "\\first_time_prep_input" + '.txt')

     workbook = load_workbook(input_file_path)
     sheet = workbook.active
     
     owl_file_path = sheet['B1'].value
     anns_to_translate_file_path = sheet['B3'].value
     
     ## Other variables ##
     
     current_date = datetime.now().date() # obtains current date
     
     ann_props_template_file = "templates/ann_props_for_review_template_file.xls"
     
     ann_props_output_file = "output/First_time/preparing_for_reviewers/First_time_ann_props_for_reviewers_" + str(current_date) + ".xls" # path (including file name and extension) of the output file for the annotation property annotations
     
     obj_props_template_file = "templates/obj_props_for_review_template_file.xls"
     
     obj_props_output_file ="output/First_time/preparing_for_reviewers/First_time_obj_props_for_reviewers_" + str(current_date) + ".xls" # path (including file name and extension) of the output file for the object property annotations
     
     data_props_template_file = "templates/data_props_for_review_template_file.xls"
     
     data_props_output_file ="output/First_time/preparing_for_reviewers/First_time_data_props_for_reviewers_" + str(current_date) + ".xls" # path (including file name and extension) of the output file for the data property annotations
      
     #####Functions#####
     copy_properties_for_review_templates(ann_props_template_file, obj_props_template_file, data_props_template_file, ann_props_output_file, obj_props_output_file, data_props_output_file)
     
     get_annotations_from_owl_file(owl_file_path, anns_to_translate_file_path, ann_props_output_file, obj_props_output_file, data_props_output_file)
         
if __name__ == '__main__':               
          main()
          