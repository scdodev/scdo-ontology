#extracting_ontology_metadata_from_ontology_GUI.py

# Program that goes through an untranslated owl file and extracts the ontology metadata, writing it into an output file.

#19 July 2021
#Jade Hotchkiss

from owlready2 import *

import os
from datetime import datetime

import shutil
from openpyxl import Workbook
from openpyxl import load_workbook

### Copies the relevant template workbook to the "output" folder and renames it as appropriate

def copy_properties_for_review_templates(ont_metadata_template_file, ont_metadata_output_file):
     shutil.copy(ont_metadata_template_file, ont_metadata_output_file)

def get_metadata_file(owl_file_path, ont_metadata_output_file):
     onto = get_ontology(owl_file_path).load()  # loads the ontology as an "onto" object
     
     workbook = load_workbook(ont_metadata_output_file)
     metadata_sheet = workbook.worksheets[0]
     
     for data in onto.metadata:
          print(data)
          print(date.name)
          #ID = ann_property.name # obtains the ID of the metadata item
          
     
def main():
     ### Opens output file from previous window and reads content
     #current_working_directory = os.getcwd() #gets the current working directory path to use in the path for the new file below
     #f = open(current_working_directory + "\\first_time_prep_input" + '.txt', 'r')
     #lines = f.readlines()
     #input_file_path = lines[0].strip()
     #f.close()
     
     #workbook = load_workbook(input_file_path)
     #sheet = workbook.active     

     #owl_file_path = sheet['B1'].value
     
     owl_file_path = "C:/Users/01440397/Dropbox/Work_2016/Translations/French Translation/ongoing_translations/March2021/Preparing_files_for_reviewers/owl_files_used/scdo_edit_used_to_generate_translations.owl"
     ## Other variables ##
     
     current_date = datetime.now().date() # obtains current date
     
     ont_metadata_template_file = "templates/ont_metadata_for_review_template_file.xlsx"

     ont_metadata_output_file = "output/First_time/preparing_for_reviewers/First_time_ont_metadata_for_reviewers_" + str(current_date) + ".xlsx" # path (including file name and extension) of the output file for the ontology metadata
     
     #####Functions#####
     copy_properties_for_review_templates(ont_metadata_template_file, ont_metadata_output_file)   
     
     get_metadata_file(owl_file_path, ont_metadata_output_file)
     
if __name__ == '__main__':               
     main()     