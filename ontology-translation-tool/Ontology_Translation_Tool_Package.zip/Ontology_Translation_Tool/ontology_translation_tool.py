#!/usr/bin/python

#program name: ontology_translation_tool.py

#13 April 2020
#Jade Hotchkiss

#colours recognised by tkinter: http://www.science.smith.edu/dftwiki/index.php/Color_Charts_for_TKinter

from tkinter import *
import tkinter as tk

import sys

#frame = tk.Frame(content, borderwidth=5, relief='ridge', width = 100, height=50)

class run_program:
    def __init__(self, window):
        ### Code to add widgets goes here:
        label = tk.Label(
            text="Welcome to the Ontology Translation Tool",
            fg="white",
            bg="black",
            width=50,
            height=5)
        label.place(x=0, y=0)
        label.pack()

        ### Adds a space between the menus
        frame = Frame(window, height=10)
        frame.pack()

        label = tk.Label(
            text="Select the type of translation you are performing:",
            height=2)
        label.pack()

        ### Adds a space between the menus
        frame = Frame(window, height=10)
        frame.pack()

        ### Creates second menu & adds submenu options
        mb1 = Menubutton(window, text="First translation",
                         relief=RAISED,
                         fg="black",
                         bg="SlateGray3",
                         height=2)

        mb1.menu= Menu (mb1, tearoff=0)
        mb1["menu"] = mb1.menu

        mb1.menu.add_command(label="Prepare files for reviewers", command = self.next_window_1)

        mb1.menu.add_command(label="Use files from reviewers", command = self.next_window_2)

        mb1.pack()

        ### Adds a space between the menus
        frame = Frame(window, height=10)
        frame.pack()

        ### Creates second menu & adds submenu options
        mb2 = Menubutton(window, text="First translation update",
                         relief=RAISED,
                         fg="black",
                         bg="SlateGray3",
                         height=2,
                         padx=5)

        mb2.menu= Menu (mb2, tearoff=0)
        mb2["menu"] = mb2.menu

        mb2.menu.add_command(label="Prepare files for reviewers", command = self.next_window_3)
       
        mb2.menu.add_command(label="Use files from reviewers", command = self.next_window_4)

        mb2.pack()
        
        ### Adds a space between the menus
        frame = Frame(window, height=10)
        frame.pack()
        
        ### Creates third menu & adds submenu options
        mb3 = Menubutton(window, text="Subsequent translation update",
                         relief=RAISED,
                         fg="black",
                         bg="SlateGray3",
                         height=2,
                         padx=5)

        mb3.menu= Menu (mb3, tearoff=0)
        mb3["menu"] = mb3.menu

        mb3.menu.add_command(label="Prepare files for reviewers", command = self.next_window_5)
       
        mb3.menu.add_command(label="Use files from reviewers", command = self.next_window_6)

        mb3.pack()        

        ### Adds a space after the second menu
        frame = Frame(window, height=20)
        frame.pack()
                
    def next_window_1(self):
        window.destroy()
        import sub_processes.first_translation_preparing_files_for_reviewers
        
    def next_window_2(self):
        window.destroy()
        import sub_processes.first_translation_using_files_from_reviewers    
        
    def next_window_3(self):
        window.destroy()
        import sub_processes.first_translation_update_preparing_files_for_reviewers
        
    def next_window_4(self):
        window.destroy()
        import sub_processes.first_translation_update_using_files_from_reviewers    
        
    def next_window_5(self):
        window.destroy()
        import sub_processes.subsequent_translation_update_preparing_files_for_reviewers
        
    def next_window_6(self):
        window.destroy()
        import sub_processes.subsequent_translation_update_using_files_from_reviewers     

window = tk.Tk() # creates the man window of the application
window.title("Ontology Translation Tool") # adds the given title to the window

###runs Tkinter event loop (listens for button clicks or keypresses, and blocks code coming after from running until the window is closed)
run_program(window)
window.mainloop() 