# sheets_to_owl.py

#Program that takes as input:
    # 1. Mapping file (mappings.xlsx)
    # 2. REDCap instrument file(s) (Instrument_resaved.csv)
    # 3. File with info about ontology (ontology_info.csv)
    # 4. Ontology owl file
    # --> And generates:
          # 1. an updated owl file with all new annotations (made by annotation properties) involved in data element mappings
          # 2. association files with all associations (made by object properties) involved in the mappings


#18 December 2020
#Jade Hotchkiss

#imports required modules
import csv
from ontology_config import * # this is a self-written module
from owlready2 import *
import types
from openpyxl import Workbook
from openpyxl import load_workbook
import zipfile
from zipfile import ZipFile
import os
from datetime import datetime

### dictionaries for annotations from data dictionary
redcapvar_section_dict = {}
redcapvar_section_order_dict = {}
redcapvar_textval_dict = {} # stores text validation as values for redcap variables
redcapvar_show_slider_dict = {}
redcapvar_autocomplete_dict = {}
redcapvar_text_val_min_dict = {}
redcapvar_text_val_max_dict = {}
redcapvar_identifier_dict = {}
redcapvar_branchinglogic_dict = {}
redcapvar_required_dict = {}
redcapvar_custom_alignment_dict = {}
redcapvar_matrix_group_dict = {}
redcapvar_field_ann_dict = {}


def reads_data_dict(data_dictionary):
     ### Reads the file with the data dictionary
     with open(data_dictionary, newline='') as csvfile:
          file_content = csv.reader(csvfile, delimiter=';', quotechar='"')
          
          section_var = ""
          order_in_section = 0
          
          for row in file_content:  # loops through the rows in the file
               
               if row[0] != "Variable / Field Name": # if the row is not the header row...
                    redcap_var = row[0] # variable storing the DE's REDCap variable
               
                    section = row[2] # variable storing the section of the instrument that the DE is in
                    if section != "": 
                         section_var = section
                         order_in_section = 1
                    if section == "":
                         if redcap_var == "record_id":
                              section = ""
                              order_in_section = ""
                         else:
                              section = section_var
                              order_in_section += 1
                              
                    ### Adds section and order in section of the DE to the relevant dictionary
                    redcapvar_section_dict[redcap_var] = section
                    redcapvar_section_order_dict[redcap_var] = order_in_section
                    if row[7] != "":
                         if row[3] == "text":
                              redcapvar_textval_dict[redcap_var] = row[7]
                         if row[3] == "slider":
                              redcapvar_show_slider_dict[redcap_var] = row[7]
                         if row[3] =="dropdown":
                              redcapvar_autocomplete_dict[redcap_var] = row[7]
                    if row[8] != "":
                         redcapvar_text_val_min_dict[redcap_var] = row[8]
                    if row[9] != "":
                         redcapvar_text_val_max_dict[redcap_var] = row[9]
                    if row[10] != "":
                         redcapvar_identifier_dict[redcap_var] = row[10]
                    if row[11] != "":
                         redcapvar_branchinglogic_dict[redcap_var] = row[11]
                    if row[12] != "":
                         redcapvar_required_dict[redcap_var] = row[12]
                    if row[13] != "":
                         redcapvar_custom_alignment_dict[redcap_var] = row[13]
                    if row[15] != "":
                         redcapvar_matrix_group_dict[redcap_var] = row[15]
                    if row[17] != "":
                         redcapvar_field_ann_dict[redcap_var] = row[17]

### dictionaries for use in next function                    
instrumentFormName_superclass_dict = {} # empty dict to which form names and superclass labels will be added as keys and values, respectively
instrumentFormName_instrumentClassLabel_dict = {} # empty dict to which form names and instrument class labels will be added as keys and values, respectively

### Generates dictionaries from ontology info file that were not obtained using the external "ontology_config" module                                   
def get_formname_superclass_instrument_dicts(ontology_info_file):
     f = open(ontology_info_file, 'r') # opens the file containing the ontology information to be used      
     for row in f:  # loops through the rows in the file
          row = (row.strip('\n')).split('\t') # strips the row of line endings and splits the row on tabs
          if row[0] == "Form name (in data dictionary):":
               instrumentFormName_superclass_dict[row[1]] = row[5]
               instrumentFormName_instrumentClassLabel_dict[row[1]] = row[3]

# Updates the most recent owl file with the new mapping information and generates the necessary association files
def update_owl_file(mappings_file, owl_file, ontology_IRI, IRI_suffix_length, IRI_suffix_number_length, instruments_to_create, DE_classes, sections_property_ID, definition_property_ID, var_property_ID, in_section_property_ID, order_in_section_property_ID, field_type_property_ID, field_label_property_ID, answer_options_text_property_ID, has_calculation_property_ID, has_slider_label_property_ID, field_note_property_ID, validation_property_ID, max_validation_property_ID, min_validation_property_ID, autocomplete_property_ID, show_slider_numbers_property_ID, is_identifier_property_ID, branching_logic_property_ID, required_field_property_ID, custom_alignment_property_ID, matrix_group_property_ID, field_annotation_property_ID, additional_code_required_ann_property_ID, LLN_data_property_ID, ULN_data_property_ID, LLN_male_data_property_ID, ULN_male_data_property_ID, LLN_female_data_property_ID, ULN_female_data_property_ID, LLN_pediatric_data_property_ID, ULN_pediatric_data_property_ID):
          
     
     ###constructs the owl file's location using the owl file name
     owl_file_location = "input/" + owl_file
     
     ###loads the owl file
     onto = get_ontology(owl_file_location).load() # loads the ontology as an "onto" object
     
     current_highest_ID_number = 0
     existing_class_labels = []
     
     neg_suffix_length = int(IRI_suffix_number_length ) * -1
     
     ### Checks IDs of current ontology classes and properties to know where to continue with new IDs and adds labels of existing classes to the "existing_class_labels" list
     for item in onto.classes(): # loops through IDs of classes and adds highest to current_highest_ID_number
          ID_number_part = int(item.iri[neg_suffix_length:])
          if ID_number_part > current_highest_ID_number:
               current_highest_ID_number = ID_number_part
          label = item.label
          if label[0] not in existing_class_labels:
               existing_class_labels.append(label[0])
          
     for item in onto.properties(): # loops through IDs of properties and adds highest to current_highest_ID_number    
          if item.iri[-12:-8] == "SCDO":
               ID_number_part = int(item.iri[neg_suffix_length:])
               if ID_number_part != 1110663:
                    if ID_number_part > current_highest_ID_number:
                         current_highest_ID_number = ID_number_part     
     print()
     print("Next highest ID number, besides SCDO_1110663: SCDO_" +str(current_highest_ID_number))
     print()
          
     ###loads the Excel "mappings" workbook to memory
     workbook = load_workbook(mappings_file) 
     
     ###labels each worksheet with a variable
     MC_sheet = workbook.worksheets[0]
     text_sheet = workbook.worksheets[1]
     text_measurements_sheet = workbook.worksheets[2]
     other_sheet = workbook.worksheets[3]
     measurements_chars_sheet = workbook.worksheets[4]
     measurements_findings_sheet = workbook.worksheets[5]
     ICD10_phenotype_sheet = workbook.worksheets[6]
     diagnoses_findings_sheet = workbook.worksheets[7]
     
     sheets_with_new_DEs = [MC_sheet, text_sheet, text_measurements_sheet, other_sheet] # creates list of all sheets containing new DE classes
     
     
     ### stores annotations and classes to be linked to in relevant dictionaries
     label_redcapvar_dict = {}
     all_new_created_DE_class_IDs_dict = {} # empty dictionary to which labels and IDs (IRI suffixes) of new classes are to be added as keys and values
     
     association_file_properties = ["collects", "has answer option", "is question type", "has answer standard unit", "has reference range standard unit", "obtained via diagnostic tool", "has possible finding", "is ICD-10-CM code type", "code requires phenotype", "diagnosed using finding"]
     association_file_objects = []
     
     for item in association_file_properties:
          new_association_file_name = "association_files/" + item + ".tsv"
          new_association_file = open(new_association_file_name, 'w', encoding="utf8") # creates the new association file for the "collects" object property
          association_file_objects.append(new_association_file)
          collects_headers = "id" + "\t" + "Term" + "\t" + item + "\n" + "ID" + "\t" + "\t" +"C '" + item + "' some %" + "\n"
          new_association_file.write(collects_headers)
     
     ### loops through the sheets in the above list and uses the content of columns A & B for non-header rows to create new classes in the ontology
     for sheet in sheets_with_new_DEs: # loops through each of the sheets with new 
          
          new_DEs_list = []
          superclasses_list = []
          
          for class_label in sheet['B'][2:]:  # loops through the values in column B, skipping the first two rows
               if class_label.value != None: # ensures only rows with content in Column B are used
                    new_DEs_list.append(class_label.value)
          
          for form_name in sheet['A'][2:]:
               if form_name.value != None: # ensures only rows with contentin Column C are used
                    superclass = instrumentFormName_superclass_dict[form_name.value] # obtains the superclass's ontology class label from the dictionary created from the ontology_info file
                    superclasses_list.append(superclass) # appends the superclass label to the list of superclasses     
          
          ### loops concurrently through the list of new DEs and list of corresponding superclasses and creates a new ontology class under its superclass 
          for new_DE_class_label, superclass in zip(new_DEs_list, superclasses_list): 
               with onto:
                                        
                    ###checks that a class with the same label doesn't already exist in the ontology
                    if new_DE_class_label not in existing_class_labels:
                         superclass_object = onto.search(label = str(superclass)) # searches for the super class's class object
                         ID_for_new_class = "SCDO_" + str(current_highest_ID_number +1) # creates the new DE classes ID (IRI suffix)
                         current_highest_ID_number += 1 # increments the value of current_highest_ID_number by 1 for use in the next new class's ID                         
                         class new_DE_class(superclass_object[0]): # creates a new class object below the superclass
                              pass
                         new_DE_class.iri = ontology_IRI + ID_for_new_class # updates the new class's IRI
                         new_DE_class.label = new_DE_class_label #updates the new class's label
                    
                         all_new_created_DE_class_IDs_dict[new_DE_class_label] = ID_for_new_class
                    
                    else:
                         print("The class '" + new_DE_class_label + "' was not created as it already exists in the ontology file.")
          
                         
          ### adds data from columns B - F to relevant dictionaries above
          for class_label, definition, redcapvar, field_label, collects in zip(sheet['B'][2:], sheet['C'][2:], sheet['D'][2:], sheet['E'][2:], sheet['F'][2:]):
               if class_label.value in all_new_created_DE_class_IDs_dict:
                    
                    class_object = onto.search(label = class_label.value)
               
                    ### Definition
                    if definition.value != None:
                         class_definition_list = getattr(class_object[0], definition_property_ID)
                         class_definition_list.append(definition.value)
                    
                    ### Redcap variable
                    if redcapvar.value != None:
                         class_redcap_vars = getattr(class_object[0], var_property_ID)
                         class_redcap_vars.append(redcapvar.value)
                    
                         #label_redcapvar_dict[class_label.value] = redcapvar.value
               
                    ### Field label     
                    if field_label.value != None:
                         class_field_labels_list = getattr(class_object[0], field_label_property_ID)
                         class_field_labels_list.append(field_label.value)
               
                    ### Collects (associations)
                    if collects.value != None:
                         ontology_ID = all_new_created_DE_class_IDs_dict[class_label.value]
                         association_file_objects[0].write(ontology_ID + "\t" + class_label.value + "\t" + collects.value + "\n")
                    else:
                         if class_label.value != None:
                              print("The collected class of '" + str(class_label.value) + "' was not in the mappings file and so was not added to the association file.")
               
                    ### Writes annotations from data dictionary to ontology class
                    if class_label.value != None:
               
                         ### CRF section
                         class_CRFsections_list = getattr(class_object[0], in_section_property_ID)
                         class_CRFsections_list.append(redcapvar_section_dict[redcapvar.value])
                    
                         ### Order in CRF section
                         class_CRFsection_order_list = getattr(class_object[0], order_in_section_property_ID)
                         class_CRFsection_order_list.append(redcapvar_section_order_dict[redcapvar.value])
                         
                         ### Redcap validation
                         if redcapvar.value in redcapvar_textval_dict:
                              class_redcap_val_list = getattr(class_object[0], validation_property_ID)
                              class_redcap_val_list.append(redcapvar_textval_dict[redcapvar.value])
                              
                         ### Show slider
                         if redcapvar.value in redcapvar_show_slider_dict:
                              class_show_slider_list = getattr(class_object[0], show_slider_numbers_property_ID)
                              class_show_slider_list.append("yes")                         
                              
                         ### Autocomplete
                         if redcapvar.value in redcapvar_autocomplete_dict:
                              class_autocomplete_list = getattr(class_object[0], autocomplete_property_ID)
                              class_autocomplete_list.append("yes")
                         
                         ### Redcap minimum number validation
                         if redcapvar.value in redcapvar_text_val_min_dict:
                              class_min_num_list = getattr(class_object[0], min_validation_property_ID)
                              class_min_num_list.append(redcapvar_text_val_min_dict[redcapvar.value])
                              
                         ### Redcap maximum number validation
                         if redcapvar.value in redcapvar_text_val_max_dict:
                              class_max_num_list = getattr(class_object[0], max_validation_property_ID)
                              class_max_num_list.append(redcapvar_text_val_max_dict[redcapvar.value])
                              
                         ### Is identifier?
                         if redcapvar.value in redcapvar_identifier_dict:
                              class_identifier_list = getattr(class_object[0], is_identifier_property_ID)
                              class_identifier_list.append(redcapvar_identifier_dict[redcapvar.value])    
                              
                         ### Branching logic
                         if redcapvar.value in redcapvar_branchinglogic_dict:
                              class_branching_logic_list = getattr(class_object[0], branching_logic_property_ID)
                              class_branching_logic_list.append(redcapvar_branchinglogic_dict[redcapvar.value])
                              
                         ### Is required?
                         if redcapvar.value in redcapvar_required_dict:
                              class_required_list = getattr(class_object[0], required_field_property_ID)
                              class_required_list.append(redcapvar_required_dict[redcapvar.value])
                              
                         ### Custom alignment
                         if redcapvar.value in redcapvar_custom_alignment_dict:
                              class_custom_align_list = getattr(class_object[0], custom_alignment_property_ID)
                              class_custom_align_list.append(redcapvar_custom_alignment_dict[redcapvar.value])
                         
                         ### Matrix group
                         if redcapvar.value in redcapvar_matrix_group_dict:
                              class_matrix_group_list = getattr(class_object[0], matrix_group_property_ID)
                              class_matrix_group_list.append(redcapvar_matrix_group_dict[redcapvar.value])
                              
                         ### Field annotation
                         if redcapvar.value in redcapvar_field_ann_dict:
                              class_field_ann_list = getattr(class_object[0], field_annotation_property_ID)
                              class_field_ann_list.append(redcapvar_field_ann_dict[redcapvar.value])                         
               
          
          ### adds data to relevant dictionaries according to the sheet being looped through
          if sheet == MC_sheet:
               for class_label, answer_options, answer_options_text, field_note, field_type, q_type in zip(sheet['B'][2:], sheet['G'][2:], sheet['H'][2:], sheet['I'][2:], sheet['J'][2:], sheet['K'][2:]):
                    class_object = onto.search(label = class_label.value) 
                    ontology_ID = all_new_created_DE_class_IDs_dict[class_label.value]
                    
                    ### Writes the associations made with "has answer options" to the association file
                    answer_options_list = answer_options.value.split('|')
                    for item in answer_options_list:
                         item = item.strip()
                         association_file_objects[1].write(ontology_ID + "\t" + class_label.value + "\t" + item + "\n")
                    
                    ### Adds the DE's answer options text annotation to its ontology class
                    class_answer_options_text_list = getattr(class_object[0], answer_options_text_property_ID)
                    class_answer_options_text_list.append(answer_options_text.value)
                    
                    ### Adds field note annotation
                    if field_note.value != None:
                         class_field_notes_list = getattr(class_object[0], field_note_property_ID)
                         class_field_notes_list.append(field_note.value)
                         
                    ### Adds field type annotation
                    class_field_type_list = getattr(class_object[0], field_type_property_ID)
                    class_field_type_list.append(field_type.value)
                    
                    ### Writes question type association to "is question type" association file
                    association_file_objects[2].write(ontology_ID + "\t" + class_label.value + "\t" + q_type.value + "\n")
                    
          else: ### Loops through sheets 2.1, 2.2 and 3
               if sheet == text_sheet or sheet == text_measurements_sheet or sheet == other_sheet:
                    for class_label, field_note, field_type in zip(sheet['B'][2:], sheet['G'][2:], sheet['H'][2:]):
                         class_object = onto.search(label = class_label.value)               
                         
                         ### Adds field note annotation
                         if field_note.value != None:
                              class_field_notes_list = getattr(class_object[0], field_note_property_ID)
                              class_field_notes_list.append(field_note.value)
                              
                         ### Adds field type annotation
                         if class_label.value != None:
                              class_field_type_list = getattr(class_object[0], field_type_property_ID)
                              class_field_type_list.append(field_type.value)                                                  
               if sheet == text_sheet or sheet == text_measurements_sheet: 
                    ### Writes question type association to "is question type" association file
                    for class_label, q_type in zip(sheet['B'][2:], sheet['I'][2:]):
                         if class_label.value != None:
                              ontology_ID = all_new_created_DE_class_IDs_dict[class_label.value]
                              association_file_objects[2].write(ontology_ID + "\t" + class_label.value + "\t" + q_type.value + "\n")
                         
               if sheet == text_measurements_sheet:
                    ### Writes answer standard unit association to "has answer standard unit" association file
                    for class_label, answer_std_unit in zip(sheet['B'][2:], sheet['J'][2:]):
                         if answer_std_unit.value != None:
                              ontology_ID = all_new_created_DE_class_IDs_dict[class_label.value]
                              association_file_objects[3].write(ontology_ID + "\t" + class_label.value + "\t" + answer_std_unit.value + "\n")

               if sheet == other_sheet:
                    for class_label, calc_eq, slider_label in zip(sheet['B'][2:], sheet['I'][2:], sheet['J'][2:]):
                         if class_label.value != None:
                              class_object = onto.search(label = class_label.value)               
                              ### Adds calculation equation annotation
                              if calc_eq.value != None:
                                   class_calc_equation_list = getattr(class_object[0], has_calculation_property_ID)
                                   class_calc_equation_list.append(calc_eq.value)
                              
                              ### Adds slider label annotation
                              if slider_label.value != None:
                                   class_slider_label_list = getattr(class_object[0], has_slider_label_property_ID)
                                   class_slider_label_list.append(slider_label.value)
     
     
     data_properties  = [LLN_data_property_ID, ULN_data_property_ID, LLN_male_data_property_ID, ULN_male_data_property_ID, LLN_female_data_property_ID, ULN_female_data_property_ID, LLN_pediatric_data_property_ID, ULN_pediatric_data_property_ID]
     
     
     ### Adds annotations and associations from sheet 4 (characterising_measurements)
     for class_label, ref_range_std_unit, ULN, LLN, ULN_male, LLN_male, ULN_female, LLN_female, ULN_pediatric, LLN_pediatric, obtained_via_diag_tool in zip(measurements_chars_sheet['A'][4:], measurements_chars_sheet['B'][4:], measurements_chars_sheet['C'][4:], measurements_chars_sheet['D'][4:], measurements_chars_sheet['E'][4:], measurements_chars_sheet['F'][4:], measurements_chars_sheet['G'][4:], measurements_chars_sheet['H'][4:], measurements_chars_sheet['I'][4:], measurements_chars_sheet['J'][4:], measurements_chars_sheet['K'][4:]):
          
          if class_label.value != None:
               class_object = onto.search(label = class_label.value)
               neg_IRI_suffix_length = int(IRI_suffix_length) * -1
               IRI_suffix_part = class_object[0].iri[neg_IRI_suffix_length:]
               
               ### Writes Reference range unit of measurement association to "has reference range standard unit" association file 
               if ref_range_std_unit.value != None:
                    association_file_objects[4].write(str(class_object[0].name) + "\t" + class_label.value + "\t" + ref_range_std_unit.value + "\n")
                    
               ### Writes Obtained via diagnostic tool association to "obtained via diagnostic tool" association file 
               if obtained_via_diag_tool.value != None:
                    association_file_objects[5].write(str(class_object[0].name) + "\t" + class_label.value + "\t" + obtained_via_diag_tool.value + "\n")
               
               data_items = [LLN, ULN, LLN_male, ULN_male, LLN_female, ULN_female, LLN_pediatric, ULN_pediatric]
               
               for data_item in data_items:
                    ### Adds ULN data property annotation
                    if data_item.value != None:
                         item_index = data_items.index(data_item)
                         data_property = data_properties[item_index]
                         data_prop_object = onto.search(label = data_property)
                         property_name = data_prop_object[0].name                         
                         data_prop_object[0].python_name = "dataPropName"
                         class_object[0].dataPropName = data_item.value
             
               
     ### Adds annotations and associations from sheet 5 (measurements-findings)
     for class_label, possible_finding in zip(measurements_findings_sheet['A'][4:], measurements_findings_sheet['B'][4:]):
          if class_label.value != None:
               if possible_finding.value != None:
                    class_object = onto.search(label = class_label.value)
                    association_file_objects[6].write(str(class_object[0].name) + "\t" + class_label.value + "\t" + possible_finding.value + "\n")
     
     ### Adds annotations and associations from sheet 6 (ICD-10-CM codes)
     for class_label, code_type, pheno_for_code, extra_code in zip(ICD10_phenotype_sheet['A'][4:], ICD10_phenotype_sheet['B'][4:], ICD10_phenotype_sheet['C'][4:], ICD10_phenotype_sheet['D'][4:]):
          if class_label.value != None:
               class_object = onto.search(label = class_label.value)               
               if code_type.value != None:
                    association_file_objects[7].write(str(class_object[0].name) + "\t" + class_label.value + "\t" + code_type.value + "\n")
                    
               if pheno_for_code.value != None:
                    association_file_objects[8].write(str(class_object[0].name) + "\t" + class_label.value + "\t" + pheno_for_code.value + "\n")
                    
               if extra_code.value != None:
                    class_extra_code_required_list = getattr(class_object[0], additional_code_required_ann_property_ID)
                    class_extra_code_required_list.append(extra_code.value) 
                    
     ### Adds annotations and associations from sheet 7 (diagnoses-findings)
     for class_label, finding_for_diagnosis in zip(diagnoses_findings_sheet['A'][4:], diagnoses_findings_sheet['B'][4:]):
          if class_label.value != None:
               class_object = onto.search(label = class_label.value)               
               if finding_for_diagnosis.value != None:
                    association_file_objects[9].write(str(class_object[0].name) + "\t" + class_label.value + "\t" + finding_for_diagnosis.value + "\n")
               
     current_date = datetime.now().date() # obtains current date
     
     ### Saves a new ontology file (rdf/xml format containing the edits made) 
     onto.save(file = ('updated_owl_' + str(current_date)) +".rdf", format = "rdfxml")
      
def main():
     ##### User Input #####  
     ## Input Files ##
     ontology_info_file = "input/ontology_info.txt" # txt file containing ontology information to be used (annotation property IDS, class names of instrument(s) to be generated, etc)
     data_dictionary = "input/instrument_resaved.csv" # name of the Excel .csv file of the REDCap data dictionary containing data elements being mapped 
     mappings_file = "input/mappings.xlsx" # name of the mappings file to be read     
               
     ##### Functions #####
     reads_data_dict(data_dictionary)
         
     owl_file, ontology_IRI, IRI_suffix_length, IRI_suffix_number_length, instruments_to_create, DE_classes, sections_property_ID, definition_property_ID, var_property_ID, in_section_property_ID, order_in_section_property_ID, field_type_property_ID, field_label_property_ID, answer_options_text_property_ID, has_calculation_property_ID, has_slider_label_property_ID, field_note_property_ID, validation_property_ID, max_validation_property_ID, min_validation_property_ID, autocomplete_property_ID, show_slider_numbers_property_ID, is_identifier_property_ID, branching_logic_property_ID, required_field_property_ID, custom_alignment_property_ID, matrix_group_property_ID, field_annotation_property_ID, additional_code_required_ann_property_ID, LLN_data_property_ID, ULN_data_property_ID, LLN_male_data_property_ID, ULN_male_data_property_ID, LLN_female_data_property_ID, ULN_female_data_property_ID, LLN_pediatric_data_property_ID, ULN_pediatric_data_property_ID = get_ontology_variables(ontology_info_file) # runs the function from the external "ontology_config" module and saves returned variables accordingly (variables used below in "update_owl_file" function)
     
     get_formname_superclass_instrument_dicts(ontology_info_file)
                     
     update_owl_file(mappings_file, owl_file, ontology_IRI, IRI_suffix_length, IRI_suffix_number_length, instruments_to_create, DE_classes, sections_property_ID, definition_property_ID, var_property_ID, in_section_property_ID, order_in_section_property_ID, field_type_property_ID, field_label_property_ID, answer_options_text_property_ID, has_calculation_property_ID, has_slider_label_property_ID, field_note_property_ID, validation_property_ID, max_validation_property_ID, min_validation_property_ID, autocomplete_property_ID, show_slider_numbers_property_ID, is_identifier_property_ID, branching_logic_property_ID, required_field_property_ID, custom_alignment_property_ID, matrix_group_property_ID, field_annotation_property_ID, additional_code_required_ann_property_ID, LLN_data_property_ID, ULN_data_property_ID, LLN_male_data_property_ID, ULN_male_data_property_ID, LLN_female_data_property_ID, ULN_female_data_property_ID, LLN_pediatric_data_property_ID, ULN_pediatric_data_property_ID)
                   
if __name__ == '__main__':               
     main()