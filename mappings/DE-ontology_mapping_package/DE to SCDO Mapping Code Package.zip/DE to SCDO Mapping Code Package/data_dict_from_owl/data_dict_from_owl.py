#data_dict_from_owl.py

#Program that extracts info from an ontology owl file and generates a data dictionary for use in creating an instrument in RedCap.

#Output:
#       1 data dictionary file

#Errors:
#       If this error occurs: "builtins.ModuleNotFoundError: No module named 'owlready2'" --> run "pip install Owlready2" in cmd
#       If you still get an error, run this command in the anaconda prompt: "conda install -c conda-forge owlready2"
#       If you still get an error, run this command in anaconda prmpt: "pip install pysqlite3"
#       If you still get an error, go to "https://www.sqlite.org/download.html" and download the appropriate dll zip file and add to "C:\Users\YOURUSER\Anaconda3\DLLs"

#23 September 2020
#Jade Hotchkiss

#imports required modules
from owlready2 import *
from ontology_config import * # this is a self-written module
import itertools  # necessary for zip() function
import zipfile
from zipfile import ZipFile
import os
from datetime import datetime     

##### Reads the owl file and extracts the necessary info for generating the data dictionary #####
def owl_to_datadict(template_file, owl_file, ontology_IRI, instruments_to_create, DE_classes, sections_property_ID, definition_property_ID, var_property_ID, in_section_property_ID, order_in_section_property_ID, field_type_property_ID, field_label_property_ID, answer_options_text_property_ID, has_calculation_property_ID, has_slider_label_property_ID, field_note_property_ID, validation_property_ID, max_validation_property_ID, min_validation_property_ID, autocomplete_property_ID, show_slider_numbers_property_ID, is_identifier_property_ID, branching_logic_property_ID, required_field_property_ID, custom_alignment_property_ID, matrix_group_property_ID, field_annotation_property_ID, additional_code_required_ann_property_ID):

      
      onto = get_ontology(owl_file).load() # loads the ontology as an "onto" object
      
      header_template_file = open(template_file, 'r', ) # opens the file with annotation properties listed in order of preference
      headers = header_template_file.readline() # reads in the first line as a list
      header_template_file.close()
      
      #newf = open('instrument.csv', 'w', encoding="utf8") # creates the new output file
      #newf.write(headers) # writes first line to output file
      #newf.write('\n') # adds line end      
     
      for instrument, DE_class  in zip(instruments_to_create, DE_classes): # loops through items in the list of instruments and the list of corresponding classes containing data elements for an instrument
            newf = open('instrument.csv', 'w', encoding="utf8") # creates the new output file
            newf.write(headers) # writes first line to output file
            newf.write('\n') # adds line end             
            
            instrument = onto.search_one(label = instrument) # gets the owl class object of the instrument to be generated
            instrument_sections = getattr(instrument, sections_property_ID)[0].split('\n') # gets the list of sectons within the instrument from the class object of the instrument to be generated
                    
            DE_section_order_dict = {} # a dictionary that has data element objects as keys and 2 values per key: the section in which the data element appears and the order of the data element in the section
            DE_annotations_dict = {} # a dictionary that has data element objects as keys and the data elements various annotations as a list of values
 
            DE_class_object = onto.search_one(label = DE_class) # gets the owl class object of the parent class of the data elements in the instrument to be generated
      
            DEs_list = onto.search(subclass_of = DE_class_object) # creates a list of all the owl class objects of the data elements in the instrument to be generated
            
            DEs_list_only_subclasses = [] # creates empty list to which all sub-classes will be added in order to remove the parent class from the list
      
            ## creates a new list of data elements, excluding the parent class
            for DE in DEs_list: #loops through class objects in the sub-class object list
                  if DE != DE_class_object: # for class objects that are not the parent class object
                        DEs_list_only_subclasses.append(DE) # adds class objects to the new list
            
            record_ID_DE = "" # sets variable to which the DE object of the record_ID DE will be added
            
            ## obtains annotations of each data element and adds to dictionary --> adds data element as key and its annotations as values (excluding the "record_id" data element)
            for DE in DEs_list_only_subclasses: # loops through list of sub-class objects
                  annotations = [] # empty list to which the DE's annotations will be added and later added as a value to the dictionary
                  DE_variables = getattr(DE, var_property_ID) # gets data element's list of redcap variables
                  DE_variable = DE_variables[0] # gets the first item in the list of redcap variables
                 
                  ## Redcap variable
                  annotations.append(DE_variable) # adds the redcap variable to the list of annotations
                  
                  ## Name of data element class (used for Form Name)    
                  annotations.append(str(instrument.label[0])) # adds name of class containing data element classes to the list of annotations
                  
                  ## Section               
                  if DE_variable != "record_id": # if the data element's redcap variable is not "record_id"...
                        in_section = getattr(DE, in_section_property_ID) # gets data element's CRF section
                        order_in_section = getattr(DE, order_in_section_property_ID) # gets data element's order in CRF section
                        DE_section_order_dict[DE]= in_section, order_in_section # adds CRF section and order in CRF section to the DE_section_order_dict dictionary
                        if order_in_section != []: # if the data element has been assigned an order number...
                              if order_in_section[0] == 1: # if it's order is "1"...
                                    section_parts = in_section[0].split('"') # splits on double quotes 
                                    new_section = '""'.join(section_parts) # joins on 2 double quotes so that the resulting string is not split on commas (becuase will be in csv file) within double quotes in the string                                  
                                    annotations.append('"' + new_section + '"') # add it' CRF section to it's list of annotations
                              else:
                                    annotations.append("") # add empty string to it's list of annotations                
                        else:
                              annotations.append("") # add empty string to it's list of annotations                                       
                  else:
                        record_ID_DE = DE # this sets the record_ID_DE variable to the data element object of the record_ID data element (special data element in Redcap)
                        annotations.append("") # add empty string to it's list of annotations    
                  
                  ## Field type
                  field_type = getattr(DE, field_type_property_ID)[0] # gets the data element's field type
                  annotations.append(field_type) # adds the redcap field type to the list of annotations for the data element
                  
                  ## Field label          
                  field_label = getattr(DE, field_label_property_ID)[0] # gets data element's field label
                  field_label = str(field_label) + ' ' # adds a space at the end of the field label so that in the final rich text field there is a space between the field label and the clickable ontology ID given in brackets
                  DE_IRI = DE.iri # gets the class's IRI
                  len_ontology_IRI = len(ontology_IRI) # determines the length of the generic ontology IRI from that provided in the input file (ontology_IRI)     
                  DE_ID = DE_IRI[len_ontology_IRI:] # uses the generic ontology IRI length to extract the class ID from the end of it's IRI
                  DE_ID = DE_ID.replace("_", ":") # replaces the _ in the ID with :
                  rich_text_field_label = '<div class="rich-text-field-label"><p>' + field_label +'(<a title="' +DE_ID + '" href="' + DE_IRI + '" target="_blank" rel="noopener">'+ DE_ID + '</a>)</p></div>' # constructs the content of the rich text field label
                  
                  label_parts = rich_text_field_label.split('"') # splits on double quotes
                  new_label = '""'.join(label_parts) # joins on 2 double quotes so that the resulting string is not split on commas (becuase will be in csv file) within double quotes in the string
                  
                  annotations.append('"' + new_label + '"') # adds rich text label to list of annotation (adding double quotes on either side so that when read as csv it doesn't get split on commas within it)
                  
                  ## Answer options or calculations added to list of annotations
                  answer_options_text = getattr(DE, answer_options_text_property_ID) # gets data element's answer options text, if there is any
                  calculation = getattr(DE, has_calculation_property_ID) # gets data element's calculation, if there is one
                  
                  slider_label = getattr(DE, has_slider_label_property_ID) # gets data element's slider label, if there is one
                                    
                  if answer_options_text != []: # identifies data elements that have answer options text
                        new_options_text = answer_options_text[0].replace("\n", " | ") # replaces line ends within the string with | so that i is read correctly in Redcap
                        annotations.append('"' + new_options_text + '"') # adds answer options text to list of annotation (adding double quotes on either side so that when read as csv it doesn't get split on commas within it)
                  
                  elif calculation != []: # identifies data elements that have a Redcap calculation equation
                        calculation_parts = calculation[0].split('"') # splits on double quotes
                        calculation = '""'.join(calculation_parts) # joins on 2 double quotes so that the resulting string is not split on commas (becuase will be in csv file) within double quotes in the string
                        annotations.append('"' + calculation + '"') # adds calculation equation to list of annotation (adding double quotes on either side so that when read as csv it doesn't get split on commas within it)
                  
                  elif slider_label != []: # identifies data elements that have a Redcap slider label
                        annotations.append('"' + slider_label[0] + '"') # adds slider label to list of annotation (adding double quotes on either side so that when read as csv it doesn't get split on commas within it)                  
                        
                  else:
                        annotations.append("") # add empty string to it's list of annotations
                  
                  ## Field note
                                  
                  field_note = getattr(DE, field_note_property_ID) # gets data element's field label
                   
                  if field_note != []:
                        annotations.append('"' + field_note[0] + '"') # adds the redcap field note to the list of annotations for the data element
                  else:
                        annotations.append("") # add empty string to it's list of annotations 
                  
                  ## Validation
                  validation = getattr(DE, validation_property_ID) # gets data element's redcap validation
                  if validation != []: # identifies data elements that have redcap validation
                        annotations.append(validation[0]) # adds the redcap validation to the list of annotations for the data element     
                  else:
                        show_slider_numbers = getattr(DE, show_slider_numbers_property_ID) # gets data element's indication of whether a slider must show number values
                        if show_slider_numbers != []: # identifies data elements that have this annotation
                              annotations.append("number") # adds the slider indication to the list of annotations for the data element
                        else:
                              autocomplete = getattr(DE, autocomplete_property_ID) # gets data element's indication of whether question options should autocomplete
                              if autocomplete != []: # identifies data elements that have this annotation
                                    annotations.append("autocomplete") # adds the autocomplete indication to the list of annotations for the data element                  
                              else:
                                    annotations.append("") # add empty string to it's list of annotations 
                  
                  ## Min Validation
                  min_validation = getattr(DE, min_validation_property_ID) # gets data element's min value for validation
                  if min_validation != []: # identifies data elements that have redcap minimum value validation
                        annotations.append(min_validation[0]) # adds the min value for validation to the list of annotations for the data element
                  
                  else:
                        annotations.append("") # add empty string to it's list of annotations 
                  
                  ## Max Validation
                  max_validation = getattr(DE, max_validation_property_ID) # gets data element's max value for validation
                  if max_validation != []: # identifies data elements that have redcap maximum value validation              
                        annotations.append(max_validation[0]) # adds the max validation to the list of annotations for the data element
                  else:
                        annotations.append("") # add empty string to it's list of annotations 

                  ## Identifier
                  identifier = getattr(DE, is_identifier_property_ID) # gets any "is identifier" annotations for the data element
                  if identifier !=[]: # identifies data elements that are identifiers
                        annotations.append(identifier[0]) # adds indication of whether or not the data element is an identifier to the list of annotations
                  else:
                        annotations.append("") # add empty string to it's list of annotations 
                  
                  ## Branching logic
                  branching_logic = getattr(DE, branching_logic_property_ID) # gets any "branching logic" for the data element
                  if branching_logic != []: # identifies data elements that have branching logic
                        annotations.append(branching_logic[0]) # adds the branching logic used for the data element the list of annotations
                  else:
                        annotations.append("") # add empty string to it's list of annotations
                  
                  ## Required field
                  required_field = getattr(DE, required_field_property_ID) # gets any "required field" annotations for the data element
                  if required_field != []: # identifies data elements that are required fields
                        annotations.append(required_field[0]) # adds the annotation added by the "required field" property to the list of annotations
                  else:
                        annotations.append("") # add empty string to it's list of annotations                  
                  
                  ## Custom alignment
                  custom_alignment = getattr(DE, custom_alignment_property_ID) # gets any "custom alignment" annotations for the data element
                  if custom_alignment != []: # identifies data elements that have custom alignment
                        annotations.append(custom_alignment[0]) # adds the custom alignment to the list of annotations
                  else:
                        annotations.append("") # add empty string to it's list of annotations
                                          
                  ## Adds blanks to "Question Number" column (only used for surveys)
                  annotations.append("") # add empty string to it's list of annotations
                  
                  ## Matrix group
                  matrix_group = getattr(DE, matrix_group_property_ID) # gets any "matrix group" annotations for the data element
                  if matrix_group != []: # identifies data elements that are in a matrix group
                        annotations.append(matrix_group[0]) # adds the matrix group to the list of annotations
                  else:                  
                        annotations.append("") # add empty string to it's list of annotations
                  
                  # Add matrix ranking here!!
                  annotations.append("") # add empty string to it's list of annotations
                  
                  ## Field annotation --> Adds ontology ID
                  field_annotation_property_ID
                  field_annotation = getattr(DE, field_annotation_property_ID)
                  if field_annotation != []:
                        field_annotation[0] = str(field_annotation[0]) +' ' + DE_ID
                        annotations.append(field_annotation[0])
                  
                  else:
                        annotations.append(DE_ID)
                                   
                  DE_annotations_dict[DE] = annotations # adds the data element's owl class object as key and list of annotations as value in the DE_annotations_dict dictionary
           
           
            ## Goes through sections in instrument and writes data element info to files
            if record_ID_DE != "": # identifies the special Redcap record_ID data element using the record_ID_DE variable (used to record the owl class object of the Redcap record_ID data element)
                  for annotation in DE_annotations_dict[record_ID_DE]: # goes through amnnotations of the special record_ID data element
                        newf.write(str(annotation) + ',') # writes each annotation to the output file
                  newf.write('\n') # write a line end to the output file
           
            for section in instrument_sections: # loops through each section in the CRF
                  DE_order_dict = {} # dictionary to which DE owl objects of DEs in the section will be added as keys and their corresponding order in the section will be added as the dictionary value
                  for DE in DE_section_order_dict:
                        if DE_section_order_dict[DE][0] != []:

                              if DE_section_order_dict[DE][0][0] == section:
                                    order_in_section = DE_section_order_dict[DE][1]
                                    if order_in_section != []:
                                          DE_order_dict[DE] = order_in_section[0]
                  order_DE_dict = {value:key for key, value in DE_order_dict.items()} # switches values and keys in DE_order_dict for new order_DE_dict dictionary
                  for item in sorted(order_DE_dict):
                        for annotation in DE_annotations_dict[order_DE_dict[item]]:
                              newf.write(str(annotation) + ',')
                        newf.write('\n')
                        
            newf.close() # closes the new data dictionary file
      
            current_date = datetime.now().date() # obtains current date
            ziparchive =  zipfile.ZipFile('output/Instrument_' + str(instrument.label[0]) + "_" +str(current_date) + '.zip', 'w') # creates a zip archive in the Output folder with the instrument name and current date in the file name
            ziparchive.write('instrument.csv') # writes the updated data dictionary to the zip archive
      
            os.remove('instrument.csv') # deletes the "instrument.csv" file that was generated in the same location as this program

      print("Program ran successfully!")

def main():
      ##### User Input #####
      
      ## Input Files ##
      ontology_info_file = "ontology_info.txt" # txt file containing ontology information to be used (annotation property IDS, class names of instrument(s) to be generated, etc)      
      template_file = "data_dict_headers_template.csv" # txt file containing headers for a Redcap data dictionary
     
      #####Functions#####
      owl_file, ontology_IRI, IRI_suffix_length, IRI_suffix_number_length, instruments_to_create, DE_classes, sections_property_ID, definition_property_ID, var_property_ID, in_section_property_ID, order_in_section_property_ID, field_type_property_ID, field_label_property_ID, answer_options_text_property_ID, has_calculation_property_ID, has_slider_label_property_ID, field_note_property_ID, validation_property_ID, max_validation_property_ID, min_validation_property_ID, autocomplete_property_ID, show_slider_numbers_property_ID, is_identifier_property_ID, branching_logic_property_ID, required_field_property_ID, custom_alignment_property_ID, matrix_group_property_ID, field_annotation_property_ID, additional_code_required_ann_property_ID, LLN_data_property_ID, ULN_data_property_ID, LLN_male_data_property_ID, ULN_male_data_property_ID, LLN_female_data_property_ID, ULN_female_data_property_ID, LLN_pediatric_data_property_ID, ULN_pediatric_data_property_ID = get_ontology_variables(ontology_info_file) # runs the function from the external "ontology_config" module and saves returned variables accordingly (variables used below in "update_owl_file" function)
      
      owl_to_datadict(template_file, owl_file, ontology_IRI, instruments_to_create, DE_classes, sections_property_ID, definition_property_ID, var_property_ID, in_section_property_ID, order_in_section_property_ID, field_type_property_ID, field_label_property_ID, answer_options_text_property_ID, has_calculation_property_ID, has_slider_label_property_ID, field_note_property_ID, validation_property_ID, max_validation_property_ID, min_validation_property_ID, autocomplete_property_ID, show_slider_numbers_property_ID, is_identifier_property_ID, branching_logic_property_ID, required_field_property_ID, custom_alignment_property_ID, matrix_group_property_ID, field_annotation_property_ID, additional_code_required_ann_property_ID)
    
if __name__ == '__main__':
      main()    