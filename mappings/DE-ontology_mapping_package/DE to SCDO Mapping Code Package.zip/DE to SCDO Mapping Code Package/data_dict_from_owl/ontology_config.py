#ontology_config.py

# A module that is reused in code that makes changes to or generates an ontology file in the process of mapping data elements to an ontology.

#5 January 2021
#Jade Hotchkiss

##### Reads the file with the ontology information to be used and saves info with relevant lists and variables #####
def get_ontology_variables(ontology_info_file):
      global owl_file
      global ontology_IRI
      global IRI_suffix_length
      global IRI_suffix_number_length
      global sections_property_ID
      global definition_property_ID
      global var_property_ID
      global in_section_property_ID
      global order_in_section_property_ID
      global field_type_property_ID      
      global field_label_property_ID
      global answer_options_text_property_ID
      global has_calculation_property_ID
      global has_slider_label_property_ID
      global field_note_property_ID
      global validation_property_ID
      global max_validation_property_ID
      global min_validation_property_ID
      global autocomplete_property_ID
      global show_slider_numbers_property_ID
      global is_identifier_property_ID
      global branching_logic_property_ID
      global required_field_property_ID
      global custom_alignment_property_ID
      global matrix_group_property_ID
      global field_annotation_property_ID
      global LLN_data_property_ID
      global ULN_data_property_ID
      global LLN_male_data_property_ID
      global ULN_male_data_property_ID
      global LLN_female_data_property_ID
      global ULN_female_data_property_ID
      global LLN_pediatric_data_property_ID
      global ULN_pediatric_data_property_ID
      global additional_code_required_ann_property_ID
      
      owl_file = "" # variable to be used for the name of the owl file to use
      instruments_to_create = [] # empty list to which names of instruments to be generated will be added
      DE_classes = [] # empty list to which names of corresponding classes with data elements will be added
      ontology_IRI = "" # variable to be used for the specific generic IRI path that is used for terms in the ontology
      IRI_suffix_length = "" # variable to be used for the IRI suffix length that is used for terms in the ontology
      IRI_suffix_number_length = "" # variable to be used for the IRI suffix number length that is used for terms in the ontology
      sections_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the sections in the instrument (e.g. "has sections")
      definition_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the definition of a data element (e.g. "definition" or "IAO_0000115")
      var_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the RedCap variable of a data element (e.g. "has SickleInAfrica data element")
      in_section_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the section of the instrument in which a data element occurs (e.g. "in CRF secction")
      order_in_section_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the order of a data element in the section of the instrument in which it occurs (e.g. "order in CRF section")
      field_type_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the order a data element's field type: (e.g. "has field type")
      field_label_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the label of a data element (e.g. "has question text")
      answer_options_text_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the answer options of a data element (e.g. "has answer options text")
      has_calculation_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the calculation used by redcap for a data element
      has_slider_label_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the slider labe; used by redcap for a slider data element
      field_note_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record a data element's field note (e.g. has field note)
      validation_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the validation redcap applies to data captured by a data element
      max_validation_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the maximum value of validation redcap applies to data captured by a data element
      min_validation_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the minimum value of validation redcap applies to data captured by a data element
      autocomplete_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record whether a dropdown field of a data element should be autocompleted
      show_slider_numbers_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record when a slider field of a data element should display the slider's number values 
      is_identifier_property_ID = ""  # variable to be used for the ontology ID of the annotation property used to show if a data element is an identifier
      branching_logic_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the branching logic used by redcap for a data element
      required_field_property_ID = "" # variable to be used for the ontology ID of the annotation property used to show if a data element is a required field
      custom_alignment_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the custom alignment used by redcap for a data element
      matrix_group_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the matrix group that a data element occurs in
      field_annotation_property_ID = "" # variable to be used for the ontology ID of the annotation property used to record the field annotations of a data element
      additional_code_required_ann_property_ID = ""
      LLN_data_property_ID = ""
      ULN_data_property_ID = ""
      LLN_male_data_property_ID = ""
      ULN_male_data_property_ID = ""
      LLN_female_data_property_ID = ""
      ULN_female_data_property_ID = ""
      LLN_pediatric_data_property_ID = ""
      ULN_pediatric_data_property_ID = ""       
      
      f = open(ontology_info_file, 'r') # opens the file containing the ontology information to be used
      
      for row in f:  # loops through the rows in the file
            row = (row.strip('\n')).split('\t') # strips the row of line endings and splits the row on tabs
            if row[0] == "OWL file:": # if the content of the first cell in the row is "OWL file"...
                  owl_file = row[1] # sets the "owl_file" variable to the IRI provided in the second cell of the row
                  
            elif row[0] == "Ontology IRI:": # if the content of the first cell in the row is this text...
                  ontology_IRI = row[1] # sets the "ontology_IRI" variable to the IRI provided in the second cell of the row
                  
            elif row[0] == "IRI suffix length (e.g. for the SCDO it's 12):": # if the content of the first cell in the row is this text...
                  IRI_suffix_length = row[1] # sets the "IRI_suffix_length" variable to the IRI suffix length provided in the second cell of the row        
                  
            elif row[0] == "IRI suffix number length (e.g. for the SCDO it's 7, e.g. SCDO:1234567):": # if the content of the first cell in the row is this text...
                  IRI_suffix_number_length = row[1] # sets the "IRI_suffix_number_length" variable to the IRI suffix number length provided in the second cell of the row
            
            elif row[2] == "Label of instrument class (in ontology):": # if the content of the first cell in the row is this text...
                  instruments_to_create.append(row[3]) # add content of second cell in row to "instruments_to_create" list
                  DE_classes.append(row[5]) # add content of fourth cell in row to "DE_classes" list
                             
            elif row[0] == "annotation property used to record the sections in an instrument:": # if the content of the first cell in the row is this text...
                  sections_property_ID = row[3] # sets the "sections_property_ID" variable to the ID provided in the fourth cell of the row
                  
            elif row[0] == "annotation property used to record the definition of a data element:": # if the content of the first cell in the row is this text...
                  definition_property_ID = row[3] # sets the "definition_property_ID" variable to the ID provided in the fourth cell of the row

            elif row[0] == "annotation property used to record the RedCap variable of a data element:": #if the content of the first cell in the row is this text...
                  var_property_ID = row[3] # sets the "var_property_ID" variable to the ID provided in the fourth cell of the row
                  
            elif row[0] == "annotation property used to record the field label of a data element:": # if the content of the first cell in the row is this text...
                  field_label_property_ID = row[3] # sets the "field_label_property_ID" variable to the ID provided in the fourth cell of the row            
      
            elif row[0] == "annotation property used to record the section of the instrument in which a data element occurs:": # if the content of the first cell in the row is this text...
                  in_section_property_ID = row[3] # sets the "in_section_property_ID" variable to the ID provided in the fourth cell of the row
                  
            elif row[0] == "annotation property used to record the position of a data element in its section in an instrument:": # if the content of the first cell in the row is this text...
                  order_in_section_property_ID = row[3] # sets the "order_in_section_property_ID" variable to the ID provided in the fourth cell of the row
                  
            elif row[0] == "annotation property used to record a data element's field type:": # if the content of the first cell in the row is this text...
                  field_type_property_ID = row[3] # sets the "field_type_property_ID" variable to the ID provided in the fourth cell of the row            
      
            elif row[0] == "annotation property used to record a data element's answer options text for input in Redcap:": # if the content of the first cell in the row is this text...
                  answer_options_text_property_ID = row[3] # sets the "answer_options_text_property_ID" variable to the ID provided in the fourth cell of the row
                  
            elif row[0] == "annotation property used to record the calculation used by redcap for a data element:": # if the content of the first cell in the row is this text...
                  has_calculation_property_ID = row[3] # sets the "has_calculation_property_ID" variable to the ID provided in the fourth cell of the row
                  
            elif row[0] == "annotation property used to record the slider label used by redcap for a data element that uses a slider to collect data:": # if the content of the first cell in the row is this text...
                  has_slider_label_property_ID = row[3] # sets the "has_slider_label_property_ID" variable to the ID provided in the fourth cell of the row            
            
            elif row[0] == "annotation property used to record a data element's field note:": # if the content of the first cell in the row is this text...
                  field_note_property_ID = row[3] # sets the "field_note_property_ID" variable to the ID provided in the fourth cell of the row
      
            elif row[0] == "annotation property used to record the validation redcap applies to data captured by a data element:": # if the content of the first cell in the row is this text...
                  validation_property_ID = row[3] # sets the "validation_property_ID" variable to the ID provided in the fourth cell of the row
            
            elif row[0] == "annotation property used to record the max value used in validating data captured by a data element in redcap:": # if the content of the first cell in the row is this text...
                  max_validation_property_ID = row[3] # sets the "max_validation_property_ID" variable to the ID provided in the fourth cell of the row
            
            elif row[0] == "annotation property used to record the min value used in validating data captured by a data element in redcap:": # if the content of the first cell in the row is this text...
                  min_validation_property_ID = row[3] # sets the "min_validation_property_ID" variable to the ID provided in the fourth cell of the row
                  
            elif row[0] == "annotation property used to record whether a dropdown field of a data element should be autocompleted:": # if the content of the first cell in the row is this text...
                  autocomplete_property_ID = row[3] # sets the "autocomplete_property_ID" variable to the ID provided in the fourth cell of the row
            
            elif row[0] == "annotation property used to record when a slider field of a data element should display the slider's number values:": # if the content of the first cell in the row is this text...
                  show_slider_numbers_property_ID = row[3] # sets the "show_slider_numbers_property_ID" variable to the ID provided in the fourth cell of the row            
            
            elif row[0] == "annotation property used to show if a data element contains identifying information:": # if the content of the first cell in the row is this text...
                  is_identifier_property_ID = row[3] # sets the "is_identifier_property_ID" variable to the ID provided in the fourth cell of the row              
      
            elif row[0] == "annotation property used to record the branching logic used by redcap for a data element:": # if the content of the first cell in the row is this text...
                  branching_logic_property_ID = row[3] # sets the "branching_logic_property_ID" variable to the ID provided in the fourth cell of the row
                  
            elif row[0] == "annotation property used to show if the data element is a required field:": # if the content of the first cell in the row is this text...
                  required_field_property_ID = row[3] # sets the "required_field_property_ID" variable to the ID provided in the fourth cell of the row
            
            elif row[0] == "annotation property used to record the matrix group that a data element occurs in:": # if the content of the first cell in the row is this text...
                  matrix_group_property_ID = row[3] # sets the "matrix_group_property_ID" variable to the ID provided in the fourth cell of the row
                  
            elif row[0] == "annotation property used to record the custom alignment used by redcap for a data element:": # if the content of the first cell in the row is this text...
                  custom_alignment_property_ID = row[3] # sets the "custom_alignment_property_ID" variable to the ID provided in the fourth cell of the row
                  
            elif row[0] == "annotation property used to record the field annotations of a data element in REDCap:": # if the content of the first cell in the row is this text...
                  field_annotation_property_ID = row[3] # sets the "custom_alignment_property_ID" variable to the ID provided in the fourth cell of the row
                  
            elif row[0] == "annotation property used to record whether or not a clinical code requires an additional code to be specified with it:": # if the content of the first cell in the row is this text...
                  additional_code_required_ann_property_ID = row[3] # sets the "additional_code_required_ann_property_ID" variable to the ID provided in the fourth cell of the row
                  
            elif row[0] == "data property used to record the lowest limit of normal for a particular laboratory result or other quantitative parameter:": # if the content of the first cell in the row is this text...
                  LLN_data_property_ID = row[1] # sets the "LLN_data_property_ID" variable to the ID provided in the second cell of the row
                  
            elif row[0] == "data property used to record the upper limit of normal for a particular laboratory result or other quantitative parameter:": # if the content of the first cell in the row is this text...
                  ULN_data_property_ID = row[1] # sets the "ULN_data_property_ID" variable to the ID provided in the second cell of the row
                  
            elif row[0] == "data property used to record the lowest limit of normal for males for a particular laboratory result or other quantitative parameter:": # if the content of the first cell in the row is this text...
                  LLN_male_data_property_ID = row[1] # sets the "LLN_male_data_property_ID" variable to the ID provided in the second cell of the row
                  
            elif row[0] == "data property used to record the upper limit of normal for males for a particular laboratory result or other quantitative parameter:": # if the content of the first cell in the row is this text...
                  ULN_male_data_property_ID = row[1] # sets the "ULN_male_data_property_ID" variable to the ID provided in the second cell of the row
                  
            elif row[0] == "data property used to record the lowest limit of normal for females for a particular laboratory result or other quantitative parameter:": # if the content of the first cell in the row is this text...
                  LLN_female_data_property_ID = row[1] # sets the "LLN_female_data_property_ID" variable to the ID provided in the second cell of the row
                  
            elif row[0] == "data property used to record the upper limit of normal for females for a particular laboratory result or other quantitative parameter:": # if the content of the first cell in the row is this text...
                  ULN_female_data_property_ID = row[1] # sets the "ULN_female_data_property_ID" variable to the ID provided in the second cell of the row
            
            elif row[0] == "data property used to record the lowest limit of normal for children for a particular laboratory result or other quantitative parameter:": # if the content of the first cell in the row is this text...
                  LLN_pediatric_data_property_ID = row[1] # sets the "LLN_children_data_property_ID" variable to the ID provided in the second cell of the row
                  
            elif row[0] == "data property used to record the upper limit of normal for children for a particular laboratory result or other quantitative parameter:": # if the content of the first cell in the row is this text...
                  ULN_pediatric_data_property_ID = row[1] # sets the "ULN_children_data_property_ID" variable to the ID provided in the second cell of the row           
      
           
      f.close() # closes the ontology_info.txt file
                 
      return owl_file, ontology_IRI, IRI_suffix_length, IRI_suffix_number_length, instruments_to_create, DE_classes, sections_property_ID, definition_property_ID, var_property_ID, in_section_property_ID, order_in_section_property_ID, field_type_property_ID, field_label_property_ID, answer_options_text_property_ID, has_calculation_property_ID, has_slider_label_property_ID, field_note_property_ID, validation_property_ID, max_validation_property_ID, min_validation_property_ID, autocomplete_property_ID, show_slider_numbers_property_ID, is_identifier_property_ID, branching_logic_property_ID, required_field_property_ID, custom_alignment_property_ID, matrix_group_property_ID, field_annotation_property_ID, additional_code_required_ann_property_ID, LLN_data_property_ID, ULN_data_property_ID, LLN_male_data_property_ID, ULN_male_data_property_ID, LLN_female_data_property_ID, ULN_female_data_property_ID, LLN_pediatric_data_property_ID, ULN_pediatric_data_property_ID