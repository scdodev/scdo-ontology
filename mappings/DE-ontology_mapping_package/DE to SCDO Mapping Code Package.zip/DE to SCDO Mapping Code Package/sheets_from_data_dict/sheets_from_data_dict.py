# sheets_from_data_dict.py


#Program that takes a REDCap data dictionary as input and generates files for use in creating data element mappings to an ontology.

#Requirements:

#ERROR:
       # If you get the error: builtins.ModuleNotFoundError: No module named 'openpyxl':
         # --> run "pip install openpyxl" in the command prompt

#19 November 2020
#Jade Hotchkiss

import shutil
import csv
from openpyxl import Workbook
from openpyxl import load_workbook

### Copies the template workbook to the same location as the python program and renames as "mappings"
def copy_mapping_sheets_template(excel_template, mappings_file):
     shutil.copy(excel_template, mappings_file)

### Extracts relevant content from data dictionary and writes to mapping sheets
def write_from_data_dict_to_sheets(data_dictionary, mappings_file):
     
     workbook = load_workbook(mappings_file)     
     MC_sheet = workbook.worksheets[0]
     text_sheet = workbook.worksheets[1]
     other_sheet = workbook.worksheets[3]  
     
     ### Reads the file with the data dictionary
     with open(data_dictionary, newline='') as csvfile:
          file_content = csv.reader(csvfile, delimiter=';', quotechar='"')
          
          for row in file_content:  # loops through the rows in the file

               if row[0] != "Variable / Field Name": # if the row is not the header row...

                    cells_for_sheet = []
               
                    redcap_var = row[0] # variable storing the DE's REDCap variable

                    instrument = row[1] # variable storing the name of the instrument that the DE is in

                    field_type = row[3]
               
                    field_label = row[4]
               
                    choices_calcs_slider_labels = row[5]
               
                    field_note = row[6]
               
                    validation_OR_show_slider_num = row[7]
               
                    question_type = ""
               
                    general_headers = [instrument, "", "", redcap_var, field_label, ""]
               
                    cells_for_sheet.extend(general_headers)

                    if field_type == "text":
                         ### determines the text question type class to link to
                         if redcap_var == "record_id":
                              extra_headers = [field_note, field_type, "", ""]
                              cells_for_sheet.extend(extra_headers)
                              other_sheet.append(cells_for_sheet)
                         
                         elif validation_OR_show_slider_num != "":
                              question_type = "Open-Ended Question - Restricted"
                              extra_headers = [field_note, field_type, question_type]
                              cells_for_sheet.extend(extra_headers) # adds relevant content to the cells_for_sheet list to be written to the sheets for text DEs
                              text_sheet.append(cells_for_sheet)
                         else:
                              question_type = "Open-Ended Question - Free Text"
                              extra_headers = [field_note, field_type, question_type]
                              cells_for_sheet.extend(extra_headers) # adds relevant content to the cells_for_sheet list to be written to the sheets for text DEs
                              text_sheet.append(cells_for_sheet)                         
               
                    ### specifies the multiple choice question type class to link to
                    elif field_type == "checkbox":
                         question_type = "Multiple Choice Multiple Selection Question"
                    elif field_type == "radio" or field_type == "dropdown":
                         question_type = "Multiple Choice Single Selection Question"
                    elif field_type == "yesno":  
                         question_type = "Yes-No Question"
                    elif field_type == "truefalse":  
                         question_type = "True-False Question"
                    else:
                         question_type = ""
                    
                    if field_type == "checkbox" or field_type == "radio" or field_type == "dropdown" or field_type == "yesno" or field_type == "truefalse":
                         if field_type == "yesno":
                              answer_classes = "Yes |No"
                              answer_text = "1, Yes\n 2, No"
                         else:
                              answers_list = choices_calcs_slider_labels.split('|') # splits the row on |
                              answer_classes_list = []
                              for answer_class in answers_list:
                                   answer_class_parts_list = answer_class.split(',')
                                   new_answer_class = answer_class_parts_list[1] # selects the second item in the list 
                                   new_answer_class = new_answer_class[1:] # removes space at start of string
                                   answer_classes_list.append(new_answer_class)
                              answer_classes = "|".join(answer_classes_list)
                              answer_text = "\n".join(answers_list)
                         extra_headers = [answer_classes, answer_text, field_note, field_type, question_type]
                         cells_for_sheet.extend(extra_headers) # adds all the DE's relevant content to the cells_for_sheet list to be written to the sheets
                         MC_sheet.append(cells_for_sheet)
                    
                    if field_type == "slider":
                         extra_headers = [field_note, field_type, "", choices_calcs_slider_labels]
                         cells_for_sheet.extend(extra_headers) # adds all the DE's relevant content to the cells_for_sheet list to be written to the sheets
                         other_sheet.append(cells_for_sheet)
               
                    if field_type == "calc":
                         extra_headers = [field_note, field_type, choices_calcs_slider_labels, ""]
                         cells_for_sheet.extend(extra_headers) # adds all the DE's relevant content to the cells_for_sheet list to be written to the sheets
                         other_sheet.append(cells_for_sheet)
                    
                    if field_type == "file" or field_type == "descriptive":
                         extra_headers = [field_note, field_type, "", ""]
                         cells_for_sheet.extend(extra_headers)               
                         other_sheet.append(cells_for_sheet)                  

     workbook.save(mappings_file)
          
def main():
     ##### User Input #####  
     ## Input Files ##
     data_dictionary = "instrument_resaved.csv" # name of the Excel .csv file of the REDCap data dictionary containing data elements to be mapped to an ontology.
     excel_template = "template\sheets_template.xlsx" # name of the template Excel .csv file used for creating the mapping sheets
     
     ## Other variables ##
     mappings_file = "mappings_1Feb.xlsx" #name of mappings file to be generated
     
     ##### Functions #####
     copy_mapping_sheets_template(excel_template, mappings_file)
     write_from_data_dict_to_sheets(data_dictionary, mappings_file)
         
if __name__ == '__main__':               
          main()